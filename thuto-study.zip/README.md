# Thuto Study 1.0

A study planner for students. Android first, built with Expo (React Native), TypeScript, Expo Router and SQLite. Everything works offline and all data stays on the phone.

## Features

- **Splash and motivation**: logo, name, then a short motivational message (62 built in, no repeats until all have been shown)
- **First-time tour**: welcome screen, a spotlight tour of the real screens, optional quick setup, then a "you're ready" screen. Replay it any time from Settings.
- **Home**: greeting, tasks due, focus time today, study streak, next exam countdown, today's classes
- **Tasks**: add, edit, complete and filter homework by subject, with due dates, priority and notes
- **Focus**: study timer that records sessions per subject
- **Planner**: weekly class timetable and an exams list with countdowns
- **Test Scores**: record tests per subject (score and total marks, percentage worked out for you), see latest, average, highest, lowest, change since the last test, overall improvement, an Improving / Stable / Declining indicator and a score-over-time graph, plus an overall dashboard
- **Progress**: weekly focus chart, time per subject, task completion, best subject and subjects needing attention
- **Settings**: name, form, subjects, light/dark mode, study times, replay tour, erase data

## Offline storage

Everything is stored in one local SQLite database (`thuto-study.db`, name kept so existing data carries over). Test scores use a `tests` table next to the existing subjects table. The recently shown motivational messages are kept in the `settings` table. Nothing needs an internet connection.

## Get an installable APK (no computer needed)

A GitHub Actions workflow (`.github/workflows/build-apk.yml`) builds the APK for you.

1. In your repo, upload `thuto-study.zip` (Add file, then Upload files, same file name replaces the old one). Do not unzip it.
2. The build starts by itself. Open the Actions tab to watch it (about 10 to 15 minutes).
3. Open the finished run (green tick) and download the **thuto-study-apk** artifact.
4. Unzip it on your phone, tap the `.apk`, and allow "Install unknown apps" when asked. It installs over the old version and keeps your data.

The APK is built for 64-bit ARM phones, which is almost every phone made in the last several years.

## Alternative: Expo EAS Build

Create a free account at expo.dev, link this repo, and start a build with the `preview` profile (see `eas.json`) for an APK, or `production` for a Play Store AAB.

## Adding a step to the app tour

1. Wrap the real UI in `<TourTarget id="my-target">` on its screen.
2. Add an entry to `src/tour/steps.ts` with the screen route, the target id and the text.

## Run on a computer (optional)

```
npm install
npx expo install --fix
npx expo start
```

## What is in this app
Home, To Do, Record Study, Study Timetable and Exam Timetable, Test Scores, Progress (Study Time and Test Scores), registration (name, family name, school, grade), welcome + spotlight tour, offline motivational splash. No quiz yet.
