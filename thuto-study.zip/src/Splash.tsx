import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Logo } from './Logo';
import { nextMessage } from './motivation';

const BRAND = '#4F46E5';
const BRAND_MS = 900; // logo + name
const MESSAGE_MS = 1700; // motivational message

/**
 * Launch screen: logo and name, then a short motivational message, then the app.
 * Everything is bundled, so it works with no connection. Tap anywhere to skip.
 */
export function Splash({ dbReady, onDone }: { dbReady: boolean; onDone: () => void }) {
  const [phase, setPhase] = useState<'brand' | 'message'>('brand');
  const [message, setMessage] = useState<string | null>(null);
  const [brandTimeUp, setBrandTimeUp] = useState(false);

  const brandOpacity = useRef(new Animated.Value(0)).current;
  const brandScale = useRef(new Animated.Value(0.85)).current;
  const messageOpacity = useRef(new Animated.Value(0)).current;
  const finished = useRef(false);

  // Fade the logo in and start the minimum brand timer.
  useEffect(() => {
    Animated.parallel([
      Animated.timing(brandOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
      Animated.spring(brandScale, { toValue: 1, friction: 6, useNativeDriver: true }),
    ]).start();
    const t = setTimeout(() => setBrandTimeUp(true), BRAND_MS);
    return () => clearTimeout(t);
  }, [brandOpacity, brandScale]);

  // Pick the message as soon as the local database is open.
  useEffect(() => {
    if (!dbReady) return;
    let alive = true;
    nextMessage().then((m) => {
      if (alive) setMessage(m);
    });
    return () => {
      alive = false;
    };
  }, [dbReady]);

  // Brand -> message once both the minimum time has passed and the message is ready.
  useEffect(() => {
    if (phase !== 'brand' || !brandTimeUp || message === null) return;
    Animated.timing(brandOpacity, { toValue: 0, duration: 200, useNativeDriver: true }).start(() => {
      setPhase('message');
      Animated.timing(messageOpacity, { toValue: 1, duration: 350, useNativeDriver: true }).start();
    });
  }, [phase, brandTimeUp, message, brandOpacity, messageOpacity]);

  const finish = () => {
    if (finished.current) return;
    finished.current = true;
    Animated.timing(messageOpacity, { toValue: 0, duration: 150, useNativeDriver: true }).start(() => onDone());
  };

  // Hold the message briefly, then open the app.
  useEffect(() => {
    if (phase !== 'message') return;
    const t = setTimeout(finish, MESSAGE_MS);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  return (
    <Pressable
      onPress={() => (phase === 'message' ? finish() : onDone())}
      accessibilityRole="button"
      accessibilityLabel="Thuto Study. Tap to continue."
      style={{ flex: 1, backgroundColor: BRAND, alignItems: 'center', justifyContent: 'center', padding: 32 }}
    >
      <StatusBar style="light" />

      {phase === 'brand' ? (
        <Animated.View style={{ alignItems: 'center', opacity: brandOpacity, transform: [{ scale: brandScale }] }}>
          <Logo size={120} />
          <Text style={{ fontSize: 34, fontWeight: '800', color: '#FFFFFF', marginTop: 20 }}>Thuto Study</Text>
        </Animated.View>
      ) : (
        <Animated.View style={{ alignItems: 'center', opacity: messageOpacity }}>
          <Text style={{ fontSize: 44, color: '#FBBF24', fontWeight: '800', marginBottom: 4 }}>"</Text>
          <Text
            style={{ fontSize: 24, fontWeight: '700', color: '#FFFFFF', textAlign: 'center', lineHeight: 34 }}
            accessibilityLiveRegion="polite"
          >
            {message}
          </Text>
          <View style={{ height: 3, width: 48, borderRadius: 2, backgroundColor: '#FBBF24', marginTop: 24 }} />
          <Text style={{ color: '#C7D2FE', marginTop: 14, fontWeight: '600' }}>Thuto Study</Text>
        </Animated.View>
      )}
    </Pressable>
  );
}
