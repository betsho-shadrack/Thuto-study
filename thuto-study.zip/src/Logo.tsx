import React from 'react';
import { Image } from 'react-native';

/** The Thuto Study logo (the same artwork as the app icon, bundled offline). */
export function Logo({ size = 96 }: { size?: number }) {
  return (
    <Image
      source={require('../assets/icon.png')}
      accessibilityLabel="Thuto Study logo"
      style={{ width: size, height: size, borderRadius: size * 0.26 }}
    />
  );
}
