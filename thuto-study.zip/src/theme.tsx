import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import { getSetting, setSetting } from './db';

export type Mode = 'system' | 'light' | 'dark';

const light = {
  bg: '#F5F6FA',
  card: '#FFFFFF',
  text: '#111827',
  sub: '#6B7280',
  border: '#E5E7EB',
  input: '#F3F4F6',
  primary: '#4F46E5',
  primaryText: '#FFFFFF',
  primarySoft: '#E0E7FF',
  success: '#16A34A',
  warning: '#D97706',
  danger: '#DC2626',
};

export type Colors = typeof light;

const dark: Colors = {
  bg: '#0B1020',
  card: '#151B2F',
  text: '#F3F4F6',
  sub: '#9CA3AF',
  border: '#262E47',
  input: '#1D2540',
  primary: '#818CF8',
  primaryText: '#0B1020',
  primarySoft: '#26305A',
  success: '#4ADE80',
  warning: '#FBBF24',
  danger: '#F87171',
};

export const SUBJECT_COLORS = [
  '#4F46E5', '#0EA5E9', '#14B8A6', '#22C55E', '#EAB308',
  '#F97316', '#EF4444', '#EC4899', '#A855F7', '#64748B',
];

type ThemeValue = { colors: Colors; isDark: boolean; mode: Mode; setMode: (m: Mode) => void };

const ThemeContext = createContext<ThemeValue>({
  colors: light,
  isDark: false,
  mode: 'system',
  setMode: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const [mode, setModeState] = useState<Mode>('system');

  useEffect(() => {
    getSetting('theme')
      .then((v) => {
        if (v === 'light' || v === 'dark' || v === 'system') setModeState(v);
      })
      .catch(() => {});
  }, []);

  const setMode = useCallback((m: Mode) => {
    setModeState(m);
    setSetting('theme', m).catch(() => {});
  }, []);

  const value = useMemo<ThemeValue>(() => {
    const isDark = mode === 'system' ? system === 'dark' : mode === 'dark';
    return { colors: isDark ? dark : light, isDark, mode, setMode };
  }, [mode, system, setMode]);

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => useContext(ThemeContext);
