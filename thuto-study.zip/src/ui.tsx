import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  NativeScrollEvent,
  NativeSyntheticEvent,
  Pressable,
  ScrollView,
  StyleProp,
  Text,
  TextInput,
  TextInputProps,
  View,
  ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from './theme';
import { Subject } from './db';
import { MONTHS_LONG, addDays, formatDate, fromISO, todayISO } from './dates';
import { ScrollContext, Scroller } from './tour/context';
import { TourTarget } from './tour/TourTarget';

/** Ref + scroll tracking so the app tour can scroll a target into view. */
function useScroller() {
  const ref = useRef<ScrollView>(null);
  const y = useRef(0);
  const scroller = useMemo<Scroller>(
    () => ({
      scrollTo: (to: number) => ref.current?.scrollTo({ y: to, animated: false }),
      getY: () => y.current,
    }),
    []
  );
  const onScroll = useCallback((e: NativeSyntheticEvent<NativeScrollEvent>) => {
    y.current = e.nativeEvent.contentOffset.y;
  }, []);
  return { ref, scroller, onScroll };
}

type IconName = React.ComponentProps<typeof Ionicons>['name'];

// ------------------------------------------------------------------ layout

/** A tab screen: big title, optional right-hand action, scrolling body, optional floating button. */
export function Screen({
  title,
  subtitle,
  eyebrow,
  right,
  fab,
  children,
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  right?: React.ReactNode;
  fab?: React.ReactNode;
  children: React.ReactNode;
}) {
  const { colors } = useTheme();
  const { ref, scroller, onScroll } = useScroller();
  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={{ paddingHorizontal: 16, paddingTop: 12, paddingBottom: 4, flexDirection: 'row', alignItems: 'center' }}>
        <View style={{ flex: 1 }}>
          {eyebrow ? (
            <Text style={{ fontSize: 12, fontWeight: '800', letterSpacing: 1.2, color: colors.primary, marginBottom: 2 }}>
              {eyebrow.toUpperCase()}
            </Text>
          ) : null}
          <Text style={{ fontSize: 28, fontWeight: '800', color: colors.text }}>{title}</Text>
          {subtitle ? <Text style={{ fontSize: 14, color: colors.sub, marginTop: 2 }}>{subtitle}</Text> : null}
        </View>
        {right}
      </View>
      <ScrollView
        ref={ref}
        onScroll={onScroll}
        scrollEventThrottle={16}
        contentContainerStyle={{ padding: 16, paddingBottom: 110 }}
        keyboardShouldPersistTaps="handled"
      >
        <ScrollContext.Provider value={scroller}>{children}</ScrollContext.Provider>
      </ScrollView>
      {fab}
    </SafeAreaView>
  );
}

/** Body of a pushed form screen (the header comes from the navigator). */
export function FormScreen({ children }: { children: React.ReactNode }) {
  const { colors } = useTheme();
  const { ref, scroller, onScroll } = useScroller();
  return (
    <ScrollView
      ref={ref}
      onScroll={onScroll}
      scrollEventThrottle={16}
      style={{ flex: 1, backgroundColor: colors.bg }}
      contentContainerStyle={{ padding: 16, paddingBottom: 48 }}
      keyboardShouldPersistTaps="handled"
    >
      <ScrollContext.Provider value={scroller}>{children}</ScrollContext.Provider>
    </ScrollView>
  );
}

export function Card({
  children,
  style,
  onPress,
}: {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  onPress?: () => void;
}) {
  const { colors } = useTheme();
  const base: ViewStyle = {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  };
  if (onPress) {
    return (
      <Pressable onPress={onPress} style={({ pressed }) => [base, style, pressed && { opacity: 0.75 }]}>
        {children}
      </Pressable>
    );
  }
  return <View style={[base, style]}>{children}</View>;
}

export function SectionTitle({ children, action }: { children: string; action?: React.ReactNode }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 14, marginBottom: 8 }}>
      <Text style={{ flex: 1, fontSize: 16, fontWeight: '700', color: colors.text }}>{children}</Text>
      {action}
    </View>
  );
}

export function Empty({ icon, text }: { icon: IconName; text: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ alignItems: 'center', paddingVertical: 28, paddingHorizontal: 24 }}>
      <Ionicons name={icon} size={40} color={colors.sub} />
      <Text style={{ color: colors.sub, marginTop: 10, textAlign: 'center', lineHeight: 20 }}>{text}</Text>
    </View>
  );
}

// ---------------------------------------------------------------- controls

export function Button({
  title,
  onPress,
  variant = 'primary',
  icon,
  disabled,
  style,
}: {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'soft' | 'danger';
  icon?: IconName;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const { colors } = useTheme();
  const bg = variant === 'primary' ? colors.primary : variant === 'danger' ? 'transparent' : colors.primarySoft;
  const fg = variant === 'primary' ? colors.primaryText : variant === 'danger' ? colors.danger : colors.primary;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        {
          backgroundColor: bg,
          borderRadius: 14,
          paddingVertical: 14,
          paddingHorizontal: 18,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          opacity: disabled ? 0.45 : pressed ? 0.8 : 1,
          borderWidth: variant === 'danger' ? 1 : 0,
          borderColor: colors.danger,
        },
        style,
      ]}
    >
      {icon ? <Ionicons name={icon} size={18} color={fg} style={{ marginRight: 8 }} /> : null}
      <Text style={{ color: fg, fontWeight: '700', fontSize: 16 }}>{title}</Text>
    </Pressable>
  );
}

export function Chip({
  label,
  selected,
  color,
  onPress,
}: {
  label: string;
  selected?: boolean;
  color?: string;
  onPress?: () => void;
}) {
  const { colors } = useTheme();
  const accent = color ?? colors.primary;
  return (
    <Pressable
      onPress={onPress}
      style={{
        paddingVertical: 8,
        paddingHorizontal: 14,
        borderRadius: 999,
        marginRight: 8,
        marginBottom: 8,
        backgroundColor: selected ? accent : colors.input,
        borderWidth: 1,
        borderColor: selected ? accent : colors.border,
        flexDirection: 'row',
        alignItems: 'center',
      }}
    >
      {color && !selected ? (
        <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color, marginRight: 6 }} />
      ) : null}
      <Text style={{ color: selected ? '#FFFFFF' : colors.text, fontWeight: '600' }}>{label}</Text>
    </Pressable>
  );
}

export function Segmented<K extends string | number>({
  options,
  value,
  onChange,
}: {
  options: { key: K; label: string }[];
  value: K;
  onChange: (k: K) => void;
}) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: 'row', backgroundColor: colors.input, borderRadius: 12, padding: 3 }}>
      {options.map((o) => {
        const active = o.key === value;
        return (
          <Pressable
            key={String(o.key)}
            onPress={() => onChange(o.key)}
            style={{
              flex: 1,
              paddingVertical: 9,
              borderRadius: 10,
              alignItems: 'center',
              backgroundColor: active ? colors.card : 'transparent',
            }}
          >
            <Text style={{ fontWeight: '700', color: active ? colors.primary : colors.sub }}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Field({ label, style, ...rest }: { label: string } & TextInputProps) {
  const { colors } = useTheme();
  return (
    <View style={{ marginBottom: 16 }}>
      <Text style={{ fontSize: 13, fontWeight: '700', color: colors.sub, marginBottom: 6 }}>{label}</Text>
      <TextInput
        placeholderTextColor={colors.sub}
        style={[
          {
            backgroundColor: colors.card,
            borderWidth: 1,
            borderColor: colors.border,
            borderRadius: 12,
            paddingHorizontal: 14,
            paddingVertical: 12,
            fontSize: 16,
            color: colors.text,
          },
          style,
        ]}
        {...rest}
      />
    </View>
  );
}

export function Label({ children }: { children: string }) {
  const { colors } = useTheme();
  return <Text style={{ fontSize: 13, fontWeight: '700', color: colors.sub, marginBottom: 6 }}>{children}</Text>;
}

export function Fab({ onPress, icon = 'add', tourId }: { onPress: () => void; icon?: IconName; tourId?: string }) {
  const { colors } = useTheme();
  const button = (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel="Add"
      onPress={onPress}
      style={({ pressed }) => ({
        position: tourId ? 'relative' : 'absolute',
        right: tourId ? 0 : 18,
        bottom: tourId ? 0 : 18,
        width: 58,
        height: 58,
        borderRadius: 29,
        backgroundColor: colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
        elevation: 6,
        shadowColor: '#000',
        shadowOpacity: 0.25,
        shadowRadius: 6,
        shadowOffset: { width: 0, height: 3 },
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <Ionicons name={icon} size={30} color={colors.primaryText} />
    </Pressable>
  );
  if (!tourId) return button;
  return (
    <TourTarget id={tourId} style={{ position: 'absolute', right: 18, bottom: 18, width: 58, height: 58 }}>
      {button}
    </TourTarget>
  );
}

export function Checkbox({ checked, onPress }: { checked: boolean; onPress: () => void }) {
  const { colors } = useTheme();
  return (
    <Pressable onPress={onPress} hitSlop={10}>
      <View
        style={{
          width: 26,
          height: 26,
          borderRadius: 8,
          borderWidth: 2,
          borderColor: checked ? colors.success : colors.sub,
          backgroundColor: checked ? colors.success : 'transparent',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {checked ? <Ionicons name="checkmark" size={18} color="#FFFFFF" /> : null}
      </View>
    </Pressable>
  );
}

export function Dot({ color, size = 10 }: { color: string | null; size?: number }) {
  const { colors } = useTheme();
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color ?? colors.sub }} />
  );
}

export function Bar({ value, max, color }: { value: number; max: number; color?: string }) {
  const { colors } = useTheme();
  const pct = max <= 0 ? 0 : Math.min(100, Math.round((value / max) * 100));
  return (
    <View style={{ height: 8, borderRadius: 4, backgroundColor: colors.input, overflow: 'hidden' }}>
      <View style={{ width: `${pct}%`, height: 8, borderRadius: 4, backgroundColor: color ?? colors.primary }} />
    </View>
  );
}

// ------------------------------------------------------------ form pickers

/** Wrapping row of subject chips plus a "None" chip. */
export function SubjectPicker({
  subjects,
  value,
  onChange,
  allowNone = true,
}: {
  subjects: Subject[];
  value: number | null;
  onChange: (id: number | null) => void;
  allowNone?: boolean;
}) {
  const { colors } = useTheme();
  return (
    <View style={{ marginBottom: 8 }}>
      <Label>Subject</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {allowNone ? <Chip label="None" selected={value === null} color={colors.sub} onPress={() => onChange(null)} /> : null}
        {subjects.map((s) => (
          <Chip key={s.id} label={s.name} color={s.color} selected={value === s.id} onPress={() => onChange(s.id)} />
        ))}
      </View>
      {subjects.length === 0 ? (
        <Text style={{ color: colors.sub, fontSize: 12 }}>Add subjects in Settings to tag your work.</Text>
      ) : null}
    </View>
  );
}

/** Tap to open a month calendar. `value` is YYYY-MM-DD. */
export function DatePicker({
  label,
  value,
  onChange,
  optional,
}: {
  label: string;
  value: string | null;
  onChange: (v: string | null) => void;
  optional?: boolean;
}) {
  const { colors } = useTheme();
  const [open, setOpen] = useState(false);
  const start = fromISO(value ?? todayISO());
  const [view, setView] = useState({ y: start.getFullYear(), m: start.getMonth() });

  const lead = (new Date(view.y, view.m, 1).getDay() + 6) % 7;
  const total = new Date(view.y, view.m + 1, 0).getDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < lead; i++) cells.push(null);
  for (let d = 1; d <= total; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  const shift = (delta: number) => {
    const d = new Date(view.y, view.m + delta, 1);
    setView({ y: d.getFullYear(), m: d.getMonth() });
  };
  const pick = (iso: string) => {
    onChange(iso);
    const d = fromISO(iso);
    setView({ y: d.getFullYear(), m: d.getMonth() });
  };
  const iso = (day: number) =>
    `${view.y}-${String(view.m + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

  return (
    <View style={{ marginBottom: 16 }}>
      <Label>{label}</Label>
      <Pressable
        onPress={() => setOpen((o) => !o)}
        style={{
          backgroundColor: colors.card,
          borderWidth: 1,
          borderColor: colors.border,
          borderRadius: 12,
          paddingHorizontal: 14,
          paddingVertical: 13,
          flexDirection: 'row',
          alignItems: 'center',
        }}
      >
        <Ionicons name="calendar-outline" size={20} color={colors.primary} />
        <Text style={{ flex: 1, marginLeft: 10, fontSize: 16, color: value ? colors.text : colors.sub }}>
          {value ? formatDate(value) : 'No date'}
        </Text>
        <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={18} color={colors.sub} />
      </Pressable>

      {open ? (
        <View
          style={{
            marginTop: 8,
            backgroundColor: colors.card,
            borderWidth: 1,
            borderColor: colors.border,
            borderRadius: 12,
            padding: 10,
          }}
        >
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 4 }}>
            <Chip label="Today" onPress={() => pick(todayISO())} />
            <Chip label="Tomorrow" onPress={() => pick(addDays(todayISO(), 1))} />
            <Chip label="Next week" onPress={() => pick(addDays(todayISO(), 7))} />
            {optional && value ? <Chip label="Clear" color={colors.danger} onPress={() => onChange(null)} /> : null}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
            <Pressable onPress={() => shift(-1)} hitSlop={10} style={{ padding: 6 }}>
              <Ionicons name="chevron-back" size={22} color={colors.text} />
            </Pressable>
            <Text style={{ flex: 1, textAlign: 'center', fontWeight: '700', color: colors.text }}>
              {MONTHS_LONG[view.m]} {view.y}
            </Text>
            <Pressable onPress={() => shift(1)} hitSlop={10} style={{ padding: 6 }}>
              <Ionicons name="chevron-forward" size={22} color={colors.text} />
            </Pressable>
          </View>
          <View style={{ flexDirection: 'row' }}>
            {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
              <Text key={i} style={{ width: '14.2857%', textAlign: 'center', color: colors.sub, fontWeight: '700' }}>
                {d}
              </Text>
            ))}
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {cells.map((day, i) => {
              const selected = day !== null && value === iso(day);
              const isToday = day !== null && iso(day) === todayISO();
              return (
                <View key={i} style={{ width: '14.2857%', alignItems: 'center', paddingVertical: 2 }}>
                  {day === null ? null : (
                    <Pressable
                      onPress={() => pick(iso(day))}
                      style={{
                        width: 36,
                        height: 36,
                        borderRadius: 18,
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: selected ? colors.primary : 'transparent',
                        borderWidth: isToday && !selected ? 1 : 0,
                        borderColor: colors.primary,
                      }}
                    >
                      <Text style={{ color: selected ? colors.primaryText : colors.text, fontWeight: selected ? '800' : '500' }}>
                        {day}
                      </Text>
                    </Pressable>
                  )}
                </View>
              );
            })}
          </View>
        </View>
      ) : null}
    </View>
  );
}
