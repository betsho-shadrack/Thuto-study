import { useCallback, useEffect, useRef, useState } from 'react';

const listeners = new Set<() => void>();

/** Call after any write so every mounted screen reloads its data. */
export function notifyChange(): void {
  listeners.forEach((l) => l());
}

/**
 * Runs an async query, re-runs it when `deps` change, and again whenever
 * notifyChange() fires (i.e. after any database write).
 */
export function useQuery<T>(fn: () => Promise<T>, initial: T, deps: unknown[] = []) {
  const [data, setData] = useState<T>(initial);
  const [loading, setLoading] = useState(true);
  const fnRef = useRef(fn);
  fnRef.current = fn;

  const load = useCallback(async () => {
    try {
      setData(await fnRef.current());
    } catch (e) {
      console.warn('Query failed', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load, ...deps]);

  useEffect(() => {
    listeners.add(load);
    return () => {
      listeners.delete(load);
    };
  }, [load]);

  return { data, loading, reload: load };
}
