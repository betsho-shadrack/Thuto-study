import React, { useState } from 'react';
import { LayoutChangeEvent, Text, View } from 'react-native';
import { useTheme } from './theme';
import { lineSegment } from './chartMath';

export type ChartPoint = { label: string; value: number };

const HEIGHT = 150;
const PAD_L = 34;
const PAD_R = 16;
const PAD_T = 24;
const PAD_B = 6;

/**
 * Lightweight line chart of scores (0 to 100%) built from plain Views, so it
 * needs no chart library and works offline.
 */
export function ScoreChart({ points }: { points: ChartPoint[] }) {
  const { colors } = useTheme();
  const [width, setWidth] = useState(0);

  const onLayout = (e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width);
  const innerW = Math.max(0, width - PAD_L - PAD_R);
  const innerH = HEIGHT - PAD_T - PAD_B;

  const xAt = (i: number) => PAD_L + (points.length === 1 ? innerW / 2 : (innerW * i) / (points.length - 1));
  const yAt = (v: number) => PAD_T + innerH * (1 - Math.min(100, Math.max(0, v)) / 100);

  return (
    <View onLayout={onLayout} style={{ height: HEIGHT + 24 }}>
      {width > 0 ? (
        <>
          {[0, 50, 100].map((g) => (
            <View key={g}>
              <View
                style={{
                  position: 'absolute',
                  left: PAD_L,
                  right: PAD_R,
                  top: yAt(g),
                  height: 1,
                  backgroundColor: colors.border,
                }}
              />
              <Text style={{ position: 'absolute', left: 0, top: yAt(g) - 8, width: PAD_L - 6, textAlign: 'right', fontSize: 11, color: colors.sub }}>
                {g}%
              </Text>
            </View>
          ))}

          {points.slice(0, -1).map((p, i) => {
            const seg = lineSegment(xAt(i), yAt(p.value), xAt(i + 1), yAt(points[i + 1].value));
            return (
              <View
                key={`s${i}`}
                style={{
                  position: 'absolute',
                  left: seg.cx - seg.length / 2,
                  top: seg.cy - 1.5,
                  width: seg.length,
                  height: 3,
                  borderRadius: 1.5,
                  backgroundColor: colors.primary,
                  transform: [{ rotate: `${seg.angle}rad` }],
                }}
              />
            );
          })}

          {points.map((p, i) => (
            <View key={`p${i}`}>
              <View
                style={{
                  position: 'absolute',
                  left: xAt(i) - 6,
                  top: yAt(p.value) - 6,
                  width: 12,
                  height: 12,
                  borderRadius: 6,
                  backgroundColor: colors.card,
                  borderWidth: 3,
                  borderColor: colors.primary,
                }}
              />
              <Text
                style={{
                  position: 'absolute',
                  left: xAt(i) - 24,
                  top: yAt(p.value) - 24,
                  width: 48,
                  textAlign: 'center',
                  fontSize: 11,
                  fontWeight: '700',
                  color: colors.text,
                }}
              >
                {Math.round(p.value)}%
              </Text>
              <Text
                numberOfLines={1}
                style={{
                  position: 'absolute',
                  left: xAt(i) - 24,
                  top: HEIGHT + 4,
                  width: 48,
                  textAlign: 'center',
                  fontSize: 11,
                  color: colors.sub,
                }}
              >
                {p.label}
              </Text>
            </View>
          ))}
        </>
      ) : null}
    </View>
  );
}
