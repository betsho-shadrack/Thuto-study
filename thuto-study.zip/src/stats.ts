/** Pure test-score maths. No React, no storage: easy to test. */

export const PASS_MARK = 50;

export type ScoreInput = { id: number; date: string; score: number; max_score: number };

export type Trend = 'improving' | 'stable' | 'declining' | 'new';
export type Category = 'improving' | 'stable' | 'attention';

export type SubjectStats = {
  count: number;
  latest: number;
  highest: number;
  lowest: number;
  average: number;
  /** latest minus the previous test, in percentage points (null with one test) */
  sinceLast: number | null;
  /** latest minus the first test, in percentage points (null with one test) */
  overallChange: number | null;
  /** (latest - first) / first, as a percent (null with one test or a first score of 0) */
  relativeChange: number | null;
  trend: Trend;
  /** percentages in date order, oldest first */
  series: number[];
};

export const percent = (t: { score: number; max_score: number }): number =>
  t.max_score > 0 ? (t.score / t.max_score) * 100 : 0;

export const formatPercent = (n: number): string => `${Math.round(n)}%`;

export const formatChange = (n: number): string => {
  const r = Math.round(n);
  return `${r > 0 ? '+' : r < 0 ? '-' : ''}${Math.abs(r)}%`;
};

/** Slope of a straight line through the last (up to) 5 results, in points per test. */
export function trendOf(series: number[]): Trend {
  if (series.length < 2) return 'new';
  const recent = series.slice(-5);
  const n = recent.length;
  const meanX = (n - 1) / 2;
  const meanY = recent.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (i - meanX) * (recent[i] - meanY);
    den += (i - meanX) * (i - meanX);
  }
  const slope = num / den;
  if (slope > 1) return 'improving';
  if (slope < -1) return 'declining';
  return 'stable';
}

/** Oldest first; tests on the same day keep the order they were entered. */
export function sortByDate<T extends { id: number; date: string }>(tests: T[]): T[] {
  return [...tests].sort((a, b) => (a.date === b.date ? a.id - b.id : a.date < b.date ? -1 : 1));
}

export function computeStats(tests: ScoreInput[]): SubjectStats | null {
  if (tests.length === 0) return null;
  const sorted = sortByDate(tests);
  const series = sorted.map(percent);
  const n = series.length;
  const latest = series[n - 1];
  const first = series[0];
  return {
    count: n,
    latest,
    highest: Math.max(...series),
    lowest: Math.min(...series),
    average: series.reduce((a, b) => a + b, 0) / n,
    sinceLast: n > 1 ? latest - series[n - 2] : null,
    overallChange: n > 1 ? latest - first : null,
    relativeChange: n > 1 && first > 0 ? ((latest - first) / first) * 100 : null,
    trend: trendOf(series),
    series,
  };
}

/** Exactly one category per subject. */
export function categorize(s: SubjectStats): Category {
  if (s.trend === 'declining') return 'attention';
  if (s.trend === 'improving') return 'improving';
  return s.latest < PASS_MARK ? 'attention' : 'stable';
}

export type Overall = {
  average: number;
  tracked: number;
  tests: number;
  improving: number;
  stable: number;
  attention: number;
};

/** Average of the subject averages, so busy subjects do not dominate. */
export function summarize(stats: SubjectStats[]): Overall {
  const out: Overall = { average: 0, tracked: stats.length, tests: 0, improving: 0, stable: 0, attention: 0 };
  if (stats.length === 0) return out;
  let sum = 0;
  for (const s of stats) {
    sum += s.average;
    out.tests += s.count;
    out[categorize(s)] += 1;
  }
  out.average = sum / stats.length;
  return out;
}
