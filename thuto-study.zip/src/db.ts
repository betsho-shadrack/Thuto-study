import * as SQLite from 'expo-sqlite';
import { notifyChange } from './store';
import { todayISO } from './dates';

export type Subject = { id: number; name: string; color: string };

export type Task = {
  id: number;
  title: string;
  subject_id: number | null;
  due_date: string | null;
  priority: number; // 0 low, 1 medium, 2 high
  notes: string;
  done: number;
  done_at: string | null;
  subject_name: string | null;
  subject_color: string | null;
};

export type Exam = {
  id: number;
  title: string;
  subject_id: number | null;
  date: string;
  time: string;
  venue: string;
  notes: string;
  subject_name: string | null;
  subject_color: string | null;
};

export type ClassSlot = {
  id: number;
  day: number; // 0 = Monday
  start: string;
  end: string;
  subject_id: number | null;
  title: string;
  room: string;
  subject_name: string | null;
  subject_color: string | null;
};

export type StudySession = {
  id: number;
  subject_id: number | null;
  minutes: number;
  day: string;
  subject_name: string | null;
  subject_color: string | null;
};

export type TestRow = {
  id: number;
  subject_id: number;
  name: string;
  date: string;
  score: number;
  max_score: number;
};

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) {
    dbPromise = init().catch((e) => {
      dbPromise = null;
      throw e;
    });
  }
  return dbPromise;
}

async function init() {
  const db = await SQLite.openDatabaseAsync('thuto-study.db');
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY NOT NULL, value TEXT);
    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      color TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      subject_id INTEGER,
      due_date TEXT,
      priority INTEGER NOT NULL DEFAULT 1,
      notes TEXT NOT NULL DEFAULT '',
      done INTEGER NOT NULL DEFAULT 0,
      done_at TEXT
    );
    CREATE TABLE IF NOT EXISTS exams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      subject_id INTEGER,
      date TEXT NOT NULL,
      time TEXT NOT NULL DEFAULT '',
      venue TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS classes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      day INTEGER NOT NULL,
      start TEXT NOT NULL,
      end TEXT NOT NULL,
      subject_id INTEGER,
      title TEXT NOT NULL DEFAULT '',
      room TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER,
      minutes INTEGER NOT NULL,
      day TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      date TEXT NOT NULL,
      score REAL NOT NULL,
      max_score REAL NOT NULL
    );
  `);
  return db;
}

// ---------------------------------------------------------------- settings

export async function getSetting(key: string): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ value: string | null }>('SELECT value FROM settings WHERE key = ?', [key]);
  return row?.value ?? null;
}

export async function setSetting(key: string, value: string): Promise<void> {
  const db = await getDb();
  await db.runAsync('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, value]);
  notifyChange();
}

// ---------------------------------------------------------------- subjects

export async function listSubjects(): Promise<Subject[]> {
  const db = await getDb();
  return db.getAllAsync<Subject>('SELECT id, name, color FROM subjects ORDER BY name COLLATE NOCASE');
}

export async function addSubject(name: string, color: string): Promise<void> {
  const db = await getDb();
  await db.runAsync('INSERT INTO subjects (name, color) VALUES (?, ?)', [name.trim(), color]);
  notifyChange();
}

export async function deleteSubject(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync('UPDATE tasks SET subject_id = NULL WHERE subject_id = ?', [id]);
  await db.runAsync('UPDATE exams SET subject_id = NULL WHERE subject_id = ?', [id]);
  await db.runAsync('UPDATE classes SET subject_id = NULL WHERE subject_id = ?', [id]);
  await db.runAsync('UPDATE sessions SET subject_id = NULL WHERE subject_id = ?', [id]);
  await db.runAsync('DELETE FROM tests WHERE subject_id = ?', [id]);
  await db.runAsync('DELETE FROM subjects WHERE id = ?', [id]);
  notifyChange();
}

// ------------------------------------------------------------------- tasks

const TASK_SELECT = `
  SELECT t.*, s.name AS subject_name, s.color AS subject_color
  FROM tasks t LEFT JOIN subjects s ON s.id = t.subject_id`;

export async function listTasks(): Promise<Task[]> {
  const db = await getDb();
  return db.getAllAsync<Task>(
    `${TASK_SELECT}
     ORDER BY t.done ASC,
              CASE WHEN t.due_date IS NULL THEN 1 ELSE 0 END,
              t.due_date ASC, t.priority DESC, t.id DESC`
  );
}

export async function getTask(id: number): Promise<Task | null> {
  const db = await getDb();
  return db.getFirstAsync<Task>(`${TASK_SELECT} WHERE t.id = ?`, [id]);
}

export async function saveTask(t: {
  id?: number;
  title: string;
  subject_id: number | null;
  due_date: string | null;
  priority: number;
  notes: string;
}): Promise<void> {
  const db = await getDb();
  if (t.id) {
    await db.runAsync(
      'UPDATE tasks SET title = ?, subject_id = ?, due_date = ?, priority = ?, notes = ? WHERE id = ?',
      [t.title.trim(), t.subject_id, t.due_date, t.priority, t.notes.trim(), t.id]
    );
  } else {
    await db.runAsync(
      'INSERT INTO tasks (title, subject_id, due_date, priority, notes) VALUES (?, ?, ?, ?, ?)',
      [t.title.trim(), t.subject_id, t.due_date, t.priority, t.notes.trim()]
    );
  }
  notifyChange();
}

export async function setTaskDone(id: number, done: boolean): Promise<void> {
  const db = await getDb();
  await db.runAsync('UPDATE tasks SET done = ?, done_at = ? WHERE id = ?', [done ? 1 : 0, done ? todayISO() : null, id]);
  notifyChange();
}

export async function deleteTask(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync('DELETE FROM tasks WHERE id = ?', [id]);
  notifyChange();
}

export async function taskCounts(): Promise<{ total: number; done: number }> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ total: number; done: number | null }>(
    'SELECT COUNT(*) AS total, SUM(done) AS done FROM tasks'
  );
  return { total: row?.total ?? 0, done: row?.done ?? 0 };
}

export async function tasksDoneSince(day: string): Promise<number> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ c: number }>('SELECT COUNT(*) AS c FROM tasks WHERE done = 1 AND done_at >= ?', [day]);
  return row?.c ?? 0;
}

// ------------------------------------------------------------------- exams

const EXAM_SELECT = `
  SELECT e.*, s.name AS subject_name, s.color AS subject_color
  FROM exams e LEFT JOIN subjects s ON s.id = e.subject_id`;

export async function listExams(): Promise<Exam[]> {
  const db = await getDb();
  return db.getAllAsync<Exam>(`${EXAM_SELECT} ORDER BY e.date ASC, e.time ASC`);
}

export async function getExam(id: number): Promise<Exam | null> {
  const db = await getDb();
  return db.getFirstAsync<Exam>(`${EXAM_SELECT} WHERE e.id = ?`, [id]);
}

export async function saveExam(e: {
  id?: number;
  title: string;
  subject_id: number | null;
  date: string;
  time: string;
  venue: string;
  notes: string;
}): Promise<void> {
  const db = await getDb();
  if (e.id) {
    await db.runAsync(
      'UPDATE exams SET title = ?, subject_id = ?, date = ?, time = ?, venue = ?, notes = ? WHERE id = ?',
      [e.title.trim(), e.subject_id, e.date, e.time, e.venue.trim(), e.notes.trim(), e.id]
    );
  } else {
    await db.runAsync(
      'INSERT INTO exams (title, subject_id, date, time, venue, notes) VALUES (?, ?, ?, ?, ?, ?)',
      [e.title.trim(), e.subject_id, e.date, e.time, e.venue.trim(), e.notes.trim()]
    );
  }
  notifyChange();
}

export async function deleteExam(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync('DELETE FROM exams WHERE id = ?', [id]);
  notifyChange();
}

// ----------------------------------------------------------------- classes

const CLASS_SELECT = `
  SELECT c.*, s.name AS subject_name, s.color AS subject_color
  FROM classes c LEFT JOIN subjects s ON s.id = c.subject_id`;

export async function listClasses(day?: number): Promise<ClassSlot[]> {
  const db = await getDb();
  if (day === undefined) return db.getAllAsync<ClassSlot>(`${CLASS_SELECT} ORDER BY c.day, c.start`);
  return db.getAllAsync<ClassSlot>(`${CLASS_SELECT} WHERE c.day = ? ORDER BY c.start`, [day]);
}

export async function getClass(id: number): Promise<ClassSlot | null> {
  const db = await getDb();
  return db.getFirstAsync<ClassSlot>(`${CLASS_SELECT} WHERE c.id = ?`, [id]);
}

export async function saveClass(c: {
  id?: number;
  day: number;
  start: string;
  end: string;
  subject_id: number | null;
  title: string;
  room: string;
}): Promise<void> {
  const db = await getDb();
  if (c.id) {
    await db.runAsync(
      'UPDATE classes SET day = ?, start = ?, end = ?, subject_id = ?, title = ?, room = ? WHERE id = ?',
      [c.day, c.start, c.end, c.subject_id, c.title.trim(), c.room.trim(), c.id]
    );
  } else {
    await db.runAsync(
      'INSERT INTO classes (day, start, end, subject_id, title, room) VALUES (?, ?, ?, ?, ?, ?)',
      [c.day, c.start, c.end, c.subject_id, c.title.trim(), c.room.trim()]
    );
  }
  notifyChange();
}

export async function deleteClass(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync('DELETE FROM classes WHERE id = ?', [id]);
  notifyChange();
}

// ---------------------------------------------------------------- sessions

export async function addSession(subjectId: number | null, minutes: number): Promise<void> {
  const db = await getDb();
  await db.runAsync('INSERT INTO sessions (subject_id, minutes, day) VALUES (?, ?, ?)', [subjectId, minutes, todayISO()]);
  notifyChange();
}

export async function recentSessions(limit = 5): Promise<StudySession[]> {
  const db = await getDb();
  return db.getAllAsync<StudySession>(
    `SELECT x.id, x.subject_id, x.minutes, x.day, s.name AS subject_name, s.color AS subject_color
     FROM sessions x LEFT JOIN subjects s ON s.id = x.subject_id
     ORDER BY x.id DESC LIMIT ?`,
    [limit]
  );
}

export async function minutesByDay(fromDay: string): Promise<{ day: string; minutes: number }[]> {
  const db = await getDb();
  return db.getAllAsync<{ day: string; minutes: number }>(
    'SELECT day, SUM(minutes) AS minutes FROM sessions WHERE day >= ? GROUP BY day',
    [fromDay]
  );
}

export async function minutesBySubject(
  fromDay: string
): Promise<{ name: string | null; color: string | null; minutes: number }[]> {
  const db = await getDb();
  return db.getAllAsync<{ name: string | null; color: string | null; minutes: number }>(
    `SELECT s.name AS name, s.color AS color, SUM(x.minutes) AS minutes
     FROM sessions x LEFT JOIN subjects s ON s.id = x.subject_id
     WHERE x.day >= ?
     GROUP BY x.subject_id
     ORDER BY minutes DESC`,
    [fromDay]
  );
}

export async function sessionDays(): Promise<string[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{ day: string }>('SELECT DISTINCT day FROM sessions ORDER BY day DESC');
  return rows.map((r) => r.day);
}

// ------------------------------------------------------------------- tests

export async function listTests(subjectId?: number): Promise<TestRow[]> {
  const db = await getDb();
  if (subjectId === undefined) {
    return db.getAllAsync<TestRow>('SELECT * FROM tests ORDER BY date ASC, id ASC');
  }
  return db.getAllAsync<TestRow>('SELECT * FROM tests WHERE subject_id = ? ORDER BY date ASC, id ASC', [subjectId]);
}

export async function getTest(id: number): Promise<TestRow | null> {
  const db = await getDb();
  return db.getFirstAsync<TestRow>('SELECT * FROM tests WHERE id = ?', [id]);
}

export async function saveTest(t: {
  id?: number;
  subject_id: number;
  name: string;
  date: string;
  score: number;
  max_score: number;
}): Promise<void> {
  const db = await getDb();
  if (t.id) {
    await db.runAsync(
      'UPDATE tests SET subject_id = ?, name = ?, date = ?, score = ?, max_score = ? WHERE id = ?',
      [t.subject_id, t.name.trim(), t.date, t.score, t.max_score, t.id]
    );
  } else {
    await db.runAsync(
      'INSERT INTO tests (subject_id, name, date, score, max_score) VALUES (?, ?, ?, ?, ?)',
      [t.subject_id, t.name.trim(), t.date, t.score, t.max_score]
    );
  }
  notifyChange();
}

export async function deleteTest(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync('DELETE FROM tests WHERE id = ?', [id]);
  notifyChange();
}

// ------------------------------------------------------------------- reset

export async function resetAll(): Promise<void> {
  const db = await getDb();
  await db.execAsync(`
    DELETE FROM tasks; DELETE FROM exams; DELETE FROM classes;
    DELETE FROM sessions; DELETE FROM tests; DELETE FROM subjects; DELETE FROM settings;
  `);
  notifyChange();
}
