const pad = (n: number) => String(n).padStart(2, '0');

export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
export const DAYS_LONG = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const MONTHS_LONG = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

/** Local calendar date as YYYY-MM-DD. */
export function toISO(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function fromISO(s: string): Date {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export const todayISO = () => toISO(new Date());

export function addDays(iso: string, n: number): string {
  const d = fromISO(iso);
  d.setDate(d.getDate() + n);
  return toISO(d);
}

/** Days from a to b (positive when b is later). */
export function daysBetween(a: string, b: string): number {
  return Math.round((fromISO(b).getTime() - fromISO(a).getTime()) / 86400000);
}

/** Monday = 0 ... Sunday = 6 */
export function weekdayIndex(iso: string): number {
  return (fromISO(iso).getDay() + 6) % 7;
}

export function startOfWeek(iso: string): string {
  return addDays(iso, -weekdayIndex(iso));
}

export function formatDate(iso: string): string {
  const d = fromISO(iso);
  return `${DAYS[weekdayIndex(iso)]}, ${d.getDate()} ${MONTHS[d.getMonth()]}`;
}

export type Tone = 'overdue' | 'today' | 'soon' | 'later' | 'none';

export function relativeDue(iso: string | null): { label: string; tone: Tone } {
  if (!iso) return { label: 'No due date', tone: 'none' };
  const diff = daysBetween(todayISO(), iso);
  if (diff < 0) return { label: diff === -1 ? 'Overdue by 1 day' : `Overdue by ${-diff} days`, tone: 'overdue' };
  if (diff === 0) return { label: 'Due today', tone: 'today' };
  if (diff === 1) return { label: 'Due tomorrow', tone: 'soon' };
  if (diff <= 7) return { label: `Due in ${diff} days`, tone: 'soon' };
  return { label: `Due ${formatDate(iso)}`, tone: 'later' };
}

export function greeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

const TIME_RE = /^([01]?\d|2[0-3]):([0-5]\d)$/;

export function isValidTime(s: string): boolean {
  return TIME_RE.test(s.trim());
}

/** "8:5" is invalid, "8:05" becomes "08:05". */
export function normalizeTime(s: string): string {
  const m = TIME_RE.exec(s.trim());
  return m ? `${pad(Number(m[1]))}:${m[2]}` : s;
}

/** Consecutive days of activity ending today (or yesterday). Input: distinct days, newest first. */
export function computeStreak(daysDesc: string[]): number {
  if (daysDesc.length === 0) return 0;
  const today = todayISO();
  let cursor = daysDesc[0] === today ? today : addDays(today, -1);
  if (daysDesc[0] !== cursor) return 0;
  let streak = 0;
  for (const d of daysDesc) {
    if (d === cursor) {
      streak += 1;
      cursor = addDays(cursor, -1);
    } else if (d < cursor) {
      break;
    }
  }
  return streak;
}

export function formatMinutes(total: number): string {
  if (total < 60) return `${total} min`;
  const h = Math.floor(total / 60);
  const m = total % 60;
  return m === 0 ? `${h} h` : `${h} h ${m} min`;
}
