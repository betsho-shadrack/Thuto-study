import React from 'react';
import { Ionicons } from '@expo/vector-icons';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

export type TourStep = {
  id: string;
  /** Screen to show while this step is active. '/settings' is a pushed screen, the rest are tabs. */
  route: string;
  /** TourTarget id of the real UI element to spotlight (see the <TourTarget id="..."> on each screen). */
  target: string;
  icon: IconName;
  title: string;
  /** What the feature does. Keep it short. */
  body: string;
  /** What the student should do first. */
  hint: string;
};

/**
 * The tour. Every step points at a feature that exists in the app today.
 *
 * To add a step for a new feature: wrap its UI in <TourTarget id="..."> and add an entry here.
 * To drop a step, delete its entry. There is no Notes / study-materials feature in the app yet,
 * so there is deliberately no step for it.
 */
export const TOUR_STEPS: TourStep[] = [
  {
    id: 'dashboard',
    route: '/(tabs)',
    target: 'home-overview',
    icon: 'home',
    title: 'Your dashboard',
    body: 'Your dashboard is your study command center. See your study progress, upcoming tasks, timetable and key study information at a glance.',
    hint: 'First: add a to do or a test score, then come back here.',
  },
  {
    id: 'tasks',
    route: '/(tabs)/tasks',
    target: 'tasks-add',
    icon: 'checkbox',
    title: 'To Do',
    body: 'Keep homework and revision in your to do list, with due dates, priorities and subjects.',
    hint: 'Tap + to add a to do. Tap the box beside it to mark it done.',
  },
  {
    id: 'focus',
    route: '/(tabs)/timer',
    target: 'focus-timer',
    icon: 'timer',
    title: 'Record Study',
    body: 'Pick a subject, start recording and study without distractions. Every session is saved to your Progress.',
    hint: 'Record a 25 minute session to start your streak.',
  },
  {
    id: 'timetable',
    route: '/(tabs)/planner',
    target: 'planner-main',
    icon: 'calendar',
    title: 'Study & Exam Timetable',
    body: 'Build your Study Timetable for when you study each subject, and switch to the Exam Timetable to count down to your exams.',
    hint: 'Tap + to add a study session or an exam. Tap any entry to edit or delete it.',
  },
  {
    id: 'scores',
    route: '/(tabs)/scores',
    target: 'scores-overview',
    icon: 'trophy',
    title: 'Tests and scores',
    body: "Track your test results and see how you're improving over time.",
    hint: 'Choose a subject, tap + and enter your score and total marks. We work out the percentage and draw your progress.',
  },
  {
    id: 'progress',
    route: '/(tabs)/progress',
    target: 'progress-week',
    icon: 'stats-chart',
    title: 'Progress',
    body: "See your Study Time and your Test Scores progress, and where you need to improve.",
    hint: 'Switch between Study Time and Test Scores at the top.',
  },
  {
    id: 'subjects',
    route: '/settings',
    target: 'settings-subjects',
    icon: 'library',
    title: 'Subjects',
    body: "Add the subjects you're currently studying so Thuto Study can organise your learning around them.",
    hint: 'Add or remove subjects here any time. To dos, timetables and scores all use them.',
  },
  {
    id: 'settings',
    route: '/settings',
    target: 'settings-help',
    icon: 'settings',
    title: 'Settings',
    body: 'Customise Thuto Study so it works the way you like: your name, family name, grade, theme and study times.',
    hint: 'You can replay this tour from here whenever you need a reminder.',
  },
];
