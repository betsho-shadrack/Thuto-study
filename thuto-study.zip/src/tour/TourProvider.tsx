import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, BackHandler, Dimensions, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { usePathname, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { setSetting } from '../db';
import { useTheme } from '../theme';
import { Button } from '../ui';
import { TargetEntry, TourApi, TourContext } from './context';
import { TOUR_STEPS, TourStep } from './steps';

export type TourMode = 'first' | 'replay';

type Rect = { x: number; y: number; width: number; height: number };

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

const sameRect = (a: Rect, b: Rect) =>
  Math.abs(a.x - b.x) < 1 && Math.abs(a.y - b.y) < 1 && Math.abs(a.width - b.width) < 1 && Math.abs(a.height - b.height) < 1;

function measure(entry: TargetEntry | undefined): Promise<Rect | null> {
  const view = entry?.ref.current;
  if (!view) return Promise.resolve(null);
  return new Promise((resolve) => {
    view.measureInWindow((x, y, width, height) => resolve(width > 0 && height > 0 ? { x, y, width, height } : null));
  });
}

/**
 * The first-run tour and the Settings replay. It spotlights the REAL elements of the app:
 * each screen wraps the element in <TourTarget id="...">, which registers it here.
 * Steps live in ./steps.ts. First run: Finish goes to the optional Setup screen, Skip goes
 * straight to the dashboard. Replay never changes the saved onboarding state.
 */
export function TourProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const [active, setActive] = useState(false);
  const [index, setIndex] = useState(0);
  const [mode, setMode] = useState<TourMode>('first');
  const [rect, setRect] = useState<Rect | null>(null);
  const [ready, setReady] = useState(false);

  const entries = useRef(new Map<string, TargetEntry>());
  const onSettings = useRef(false);
  const pathRef = useRef(pathname);
  pathRef.current = pathname;
  const total = TOUR_STEPS.length;

  const register = useCallback((id: string, entry: TargetEntry) => {
    entries.current.set(id, entry);
  }, []);
  const unregister = useCallback((id: string, entry: TargetEntry) => {
    if (entries.current.get(id) === entry) entries.current.delete(id);
  }, []);

  const start = useCallback((opts?: { replay?: boolean }) => {
    // A replay is launched from Settings, so the first step has to leave that screen.
    onSettings.current = pathRef.current === '/settings';
    setMode(opts?.replay ? 'replay' : 'first');
    setIndex(0);
    setRect(null);
    setReady(false);
    setActive(true);
  }, []);

  /** Waits until the target stops moving (screen transitions finished), up to about 3 seconds. */
  const measureStable = useCallback(async (id: string, isCancelled: () => boolean): Promise<Rect | null> => {
    let prev: Rect | null = null;
    for (let i = 0; i < 28; i++) {
      if (isCancelled()) return null;
      const m = await measure(entries.current.get(id));
      if (m && prev && sameRect(m, prev)) return m;
      prev = m;
      await sleep(110);
    }
    return prev;
  }, []);

  // Whenever the step changes: show the right screen, find the real element, scroll it into view.
  useEffect(() => {
    if (!active) return;
    const step = TOUR_STEPS[index];
    let cancelled = false;
    setReady(false);
    setRect(null);

    (async () => {
      if (step.route === '/settings') {
        if (!onSettings.current) {
          onSettings.current = true;
          router.push('/settings');
        }
      } else {
        if (onSettings.current) {
          onSettings.current = false;
          router.back();
          await sleep(80);
        }
        router.navigate(step.route as never);
      }

      let r = await measureStable(step.target, () => cancelled);

      // Bring a target that sits below the fold (or under the tooltip area) into the upper part of the screen.
      const entry = entries.current.get(step.target);
      if (r && entry?.scroller && !cancelled) {
        const winH = Dimensions.get('window').height;
        const top = insets.top + 80;
        const visibleBottom = winH * 0.6;
        const shownHeight = Math.min(r.height, winH * 0.4);
        if (r.y < top - 8 || r.y + shownHeight > visibleBottom) {
          const desired = Math.max(top, winH * 0.18);
          entry.scroller.scrollTo(Math.max(0, entry.scroller.getY() + (r.y - desired)));
          await sleep(160);
          r = await measureStable(step.target, () => cancelled);
        }
      }

      if (!cancelled) {
        setRect(r);
        setReady(true);
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, index]);

  const close = useCallback(
    async (how: 'finish' | 'skip') => {
      setActive(false);
      if (onSettings.current) {
        onSettings.current = false;
        router.back();
        await sleep(80);
      }
      if (mode === 'first') {
        try {
          await setSetting('onboarding_state', how === 'skip' ? 'skipped' : 'completed');
        } catch (e) {
          console.warn('Could not save onboarding state', e);
        }
        router.replace(how === 'skip' ? '/(tabs)' : '/setup');
      } else {
        router.navigate('/(tabs)');
      }
    },
    [mode, router]
  );

  const onNext = () => (index >= total - 1 ? close('finish') : setIndex(index + 1));
  const onBack = () => index > 0 && setIndex(index - 1);
  const onSkip = () => close('skip');

  // The hardware back button steps back through the tour instead of leaving it.
  useEffect(() => {
    if (!active) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (index > 0) setIndex((i) => i - 1);
      else close('skip');
      return true;
    });
    return () => sub.remove();
  }, [active, index, close]);

  const value = useMemo<TourApi>(() => ({ active, start, register, unregister }), [active, start, register, unregister]);

  return (
    <TourContext.Provider value={value}>
      {children}
      {active ? (
        <Overlay
          step={TOUR_STEPS[index]}
          index={index}
          total={total}
          rect={rect}
          ready={ready}
          mode={mode}
          onNext={onNext}
          onBack={onBack}
          onSkip={onSkip}
        />
      ) : null}
    </TourContext.Provider>
  );
}

const SCRIM = 'rgba(6, 8, 22, 0.78)';
const PAD = 6;

function Overlay({
  step,
  index,
  total,
  rect,
  ready,
  mode,
  onNext,
  onBack,
  onSkip,
}: {
  step: TourStep;
  index: number;
  total: number;
  rect: Rect | null;
  ready: boolean;
  mode: TourMode;
  onNext: () => void;
  onBack: () => void;
  onSkip: () => void;
}) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { width: winW, height: winH } = useWindowDimensions();
  const rootRef = useRef<View>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  const fade = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;
  const tip = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fade, { toValue: 1, duration: 200, useNativeDriver: true }).start();
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 900, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 900, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [fade, pulse]);

  useEffect(() => {
    if (!ready) return;
    tip.setValue(0);
    Animated.timing(tip, { toValue: 1, duration: 240, useNativeDriver: true }).start();
  }, [ready, index, tip]);

  // The overlay may not start at the window origin (status bar), so correct for that.
  const onLayout = () => {
    rootRef.current?.measureInWindow((x, y) => setOffset({ x, y }));
  };

  const hole =
    ready && rect
      ? {
          x: Math.max(0, rect.x - offset.x - PAD),
          y: Math.max(0, rect.y - offset.y - PAD),
          w: rect.width + PAD * 2,
          // Very tall targets (long lists) are spotlighted from the top so the tip never covers them.
          h: Math.min(rect.height, winH * 0.4) + PAD * 2,
        }
      : null;

  const dockTop = hole ? hole.y + hole.h / 2 > winH / 2 : false;
  const isLast = index === total - 1;

  return (
    <View
      ref={rootRef}
      onLayout={onLayout}
      onStartShouldSetResponder={() => true}
      accessibilityViewIsModal
      style={[StyleSheet.absoluteFill, { zIndex: 1000, elevation: 1000 }]}
    >
    <Animated.View style={[StyleSheet.absoluteFill, { opacity: fade }]}>
      {/* Dark overlay with a hole around the real element. */}
      {hole ? (
        <>
          <View style={{ position: 'absolute', left: 0, right: 0, top: 0, height: hole.y, backgroundColor: SCRIM }} />
          <View style={{ position: 'absolute', left: 0, right: 0, top: hole.y + hole.h, bottom: 0, backgroundColor: SCRIM }} />
          <View style={{ position: 'absolute', left: 0, top: hole.y, width: hole.x, height: hole.h, backgroundColor: SCRIM }} />
          <View style={{ position: 'absolute', left: hole.x + hole.w, right: 0, top: hole.y, height: hole.h, backgroundColor: SCRIM }} />
          <Animated.View
            pointerEvents="none"
            style={{
              position: 'absolute',
              left: hole.x,
              top: hole.y,
              width: hole.w,
              height: hole.h,
              borderRadius: 16,
              borderWidth: 2,
              borderColor: '#FFFFFF',
              opacity: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.55, 1] }),
            }}
          />
        </>
      ) : (
        <View style={[StyleSheet.absoluteFill, { backgroundColor: SCRIM }]} />
      )}

      {ready ? (
        <Animated.View
          style={{
            position: 'absolute',
            left: 16,
            right: 16,
            maxWidth: Math.min(winW - 32, 520),
            alignSelf: 'center',
            ...(dockTop ? { top: insets.top + 16 } : { bottom: insets.bottom + 16 }),
            opacity: tip,
            transform: [{ translateY: tip.interpolate({ inputRange: [0, 1], outputRange: [dockTop ? -12 : 12, 0] }) }],
            backgroundColor: colors.card,
            borderRadius: 22,
            padding: 16,
            elevation: 8,
            shadowColor: '#000',
            shadowOpacity: 0.3,
            shadowRadius: 12,
            shadowOffset: { width: 0, height: 4 },
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: colors.primarySoft,
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: 12,
              }}
            >
              <Ionicons name={step.icon} size={22} color={colors.primary} />
            </View>
            <Text accessibilityRole="header" style={{ flex: 1, fontSize: 19, fontWeight: '800', color: colors.text }}>
              {step.title}
            </Text>
            <Text style={{ color: colors.sub, fontWeight: '700' }} accessibilityLabel={`Step ${index + 1} of ${total}`}>
              {index + 1} of {total}
            </Text>
          </View>

          <View style={{ flexDirection: 'row', marginTop: 12, marginBottom: 12 }}>
            {Array.from({ length: total }).map((_, i) => (
              <View
                key={i}
                style={{
                  flex: 1,
                  height: 4,
                  borderRadius: 2,
                  marginRight: i === total - 1 ? 0 : 4,
                  backgroundColor: i <= index ? colors.primary : colors.border,
                }}
              />
            ))}
          </View>

          <Text style={{ fontSize: 15, lineHeight: 21, color: colors.text }}>{step.body}</Text>
          <View style={{ flexDirection: 'row', marginTop: 10 }}>
            <Ionicons name="bulb-outline" size={18} color={colors.warning} style={{ marginTop: 1 }} />
            <Text style={{ flex: 1, marginLeft: 8, fontSize: 14, lineHeight: 20, color: colors.sub }}>{step.hint}</Text>
          </View>

          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 16 }}>
            <Pressable
              onPress={onSkip}
              hitSlop={8}
              accessibilityRole="button"
              accessibilityLabel={mode === 'first' ? 'Skip the tour' : 'Close the tour'}
              style={{ paddingVertical: 10, paddingRight: 14 }}
            >
              <Text style={{ color: colors.sub, fontWeight: '700', fontSize: 15 }}>{mode === 'first' ? 'Skip' : 'Close'}</Text>
            </Pressable>
            <View style={{ flex: 1 }} />
            {index > 0 ? (
              <Button title="Back" variant="soft" onPress={onBack} style={{ paddingVertical: 10, paddingHorizontal: 18, marginRight: 8 }} />
            ) : null}
            <Button
              title={isLast ? (mode === 'first' ? 'Finish' : 'Done') : 'Next'}
              onPress={onNext}
              style={{ paddingVertical: 10, paddingHorizontal: 22 }}
            />
          </View>
        </Animated.View>
      ) : null}
    </Animated.View>
    </View>
  );
}
