import { createContext, useContext } from 'react';
import type { RefObject } from 'react';
import type { View } from 'react-native';

/** Lets the tour scroll a target into view when it sits below the fold. */
export type Scroller = { scrollTo: (y: number) => void; getY: () => number };

export type TargetEntry = { ref: RefObject<View | null>; scroller: Scroller | null };

export type TourApi = {
  active: boolean;
  /** Start the spotlight tour. `replay` is true when it is launched from Settings. */
  start: (opts?: { replay?: boolean }) => void;
  register: (id: string, entry: TargetEntry) => void;
  unregister: (id: string, entry: TargetEntry) => void;
};

export const TourContext = createContext<TourApi>({
  active: false,
  start: () => {},
  register: () => {},
  unregister: () => {},
});

export const useTour = () => useContext(TourContext);

/** Provided by Screen / FormScreen so a TourTarget knows which ScrollView it lives in. */
export const ScrollContext = createContext<Scroller | null>(null);
