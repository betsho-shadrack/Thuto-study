import React, { useContext, useEffect, useRef } from 'react';
import { StyleProp, View, ViewStyle } from 'react-native';
import { ScrollContext, useTour } from './context';

/**
 * Wrap any real piece of UI in a TourTarget to make it a stop on the app tour.
 * It renders a plain View, so it does not change the layout of what it wraps.
 */
export function TourTarget({
  id,
  children,
  style,
}: {
  id: string;
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  const ref = useRef<View>(null);
  const { register, unregister } = useTour();
  const scroller = useContext(ScrollContext);

  useEffect(() => {
    const entry = { ref, scroller };
    register(id, entry);
    return () => unregister(id, entry);
  }, [id, scroller, register, unregister]);

  return (
    <View ref={ref} collapsable={false} style={style}>
      {children}
    </View>
  );
}
