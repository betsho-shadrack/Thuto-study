/** Built-in motivational messages. Bundled in the app: no internet needed. */
export const MESSAGES: string[] = [
  // Progress and learning
  'Small progress is still progress.',
  'Your future self will thank you for studying today.',
  "Don't aim to be perfect. Aim to improve.",
  'One difficult question today can become an easy question tomorrow.',

  // Studying
  'Start with ten minutes. Momentum will do the rest.',
  'Study a little every day, not a lot once in a while.',
  'Understanding beats memorising every time.',
  'Teach it to someone else. If you can explain it, you know it.',
  'Focus on one topic at a time and finish it.',
  'One quiet hour of focus beats three distracted ones.',

  // Exams
  'Exams reward the work you did weeks ago. Keep going.',
  'Practise past papers until the exam feels familiar.',
  'Stay calm. You have prepared more than you think.',
  'Read the question twice. Answer it once, clearly.',
  'Every exam is a chance to show what you have learned.',
  'Rest well before the exam. A fresh mind remembers more.',

  // Discipline
  'Discipline is choosing what you want most over what you want now.',
  'Do it even when you do not feel like it.',
  'Motivation gets you started. Discipline keeps you going.',
  'Put the phone down. Open the book.',
  'Your habits today decide your results tomorrow.',
  'Show up on the hard days too.',

  // Consistency
  'Consistency turns ordinary effort into extraordinary results.',
  'One page a day becomes a whole book.',
  'Keep your streak alive. Even a short session counts.',
  'Little and often beats rarely and rushed.',
  'Be the student who studies even when no one is watching.',
  'Every day you study makes the next day easier.',

  // Academic improvement
  "Last term's mark is not your limit.",
  'Find your weakest topic and make it your strength.',
  'Review your mistakes. They show you exactly what to fix.',
  'Improve by one percent every day and watch what happens.',
  'Ask questions. Curious students become top students.',
  "Beat your own last score, not anyone else's.",

  // Failure and learning
  'A low mark is feedback, not a final verdict.',
  'Getting it wrong is how your brain learns it right.',
  'Mistakes are proof that you are trying.',
  'Every setback is setting you up for a comeback.',
  'You only fail when you stop trying.',
  'Learn from the mistake, then leave the guilt behind.',

  // Confidence
  'You are more capable than you think.',
  'Trust the work you have put in.',
  'You do not have to be the best. You have to do your best.',
  'Confidence grows every time you finish what you started.',
  'Speak up in class. Your question may help everyone.',
  'You belong in this classroom. Keep going.',

  // Hard work
  'Hard work beats talent when talent does not work hard.',
  'Sweat in revision, smile in the exam hall.',
  'There is no shortcut to a place worth going.',
  'Effort today, rewards tomorrow.',
  'Great marks are earned one hour at a time.',
  'The harder you work now, the more choices you will have later.',

  // Progress
  'Look back at how far you have come.',
  'Progress is quiet. Trust it even when you cannot see it.',
  'Every finished task is a step forward.',
  'You are further along than you were yesterday.',

  // Reaching goals
  'Set a goal, make a plan, then take the first step.',
  'Big dreams are built from small daily steps.',
  'Write your goal down and look at it every day.',
  'Your goal gets closer every time you study.',
  'Finish what you start. Then start the next goal.',
  'Dream it, plan it, study for it, achieve it.',
];

/**
 * Picks the next message index so that every message is shown once before any
 * repeats, and the first message of a new cycle never equals the previous one.
 * Pure function: storage is handled by the caller.
 */
export function chooseIndex(
  seen: number[],
  last: number,
  total: number,
  rand: () => number
): { index: number; seen: number[] } {
  let cycle = Array.from(new Set(seen.filter((i) => Number.isInteger(i) && i >= 0 && i < total)));
  let pool: number[] = [];
  for (let i = 0; i < total; i++) if (!cycle.includes(i)) pool.push(i);

  if (pool.length === 0) {
    cycle = [];
    for (let i = 0; i < total; i++) if (i !== last) pool.push(i);
    if (pool.length === 0) pool = [0];
  }

  const index = pool[Math.min(pool.length - 1, Math.floor(rand() * pool.length))];
  return { index, seen: [...cycle, index] };
}
