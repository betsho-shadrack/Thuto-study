import React from 'react';
import { Text, View } from 'react-native';
import { Task } from './db';
import { relativeDue } from './dates';
import { useTheme } from './theme';
import { Card, Checkbox, Dot } from './ui';

const PRIORITY_LABEL = ['Low', 'Medium', 'High'];

export function TaskRow({
  task,
  onToggle,
  onPress,
}: {
  task: Task;
  onToggle: () => void;
  onPress: () => void;
}) {
  const { colors } = useTheme();
  const done = task.done === 1;
  const due = relativeDue(task.due_date);
  const dueColor =
    done || due.tone === 'later' || due.tone === 'none' || due.tone === 'soon'
      ? colors.sub
      : due.tone === 'overdue'
      ? colors.danger
      : colors.warning;

  return (
    <Card onPress={onPress} style={{ flexDirection: 'row', alignItems: 'center', opacity: done ? 0.6 : 1 }}>
      <Checkbox checked={done} onPress={onToggle} />
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text
          style={{
            fontSize: 16,
            fontWeight: '600',
            color: colors.text,
            textDecorationLine: done ? 'line-through' : 'none',
          }}
        >
          {task.title}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 4, flexWrap: 'wrap' }}>
          {task.subject_name ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', marginRight: 10 }}>
              <Dot color={task.subject_color} size={8} />
              <Text style={{ color: colors.sub, fontSize: 13, marginLeft: 5 }}>{task.subject_name}</Text>
            </View>
          ) : null}
          <Text style={{ color: dueColor, fontSize: 13, fontWeight: due.tone === 'overdue' ? '700' : '400' }}>
            {done ? 'Completed' : due.label}
          </Text>
        </View>
      </View>
      {!done && task.priority === 2 ? (
        <Text style={{ color: colors.danger, fontSize: 12, fontWeight: '800' }}>{PRIORITY_LABEL[2]}</Text>
      ) : null}
    </Card>
  );
}
