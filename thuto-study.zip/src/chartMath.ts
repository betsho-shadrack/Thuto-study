/** Geometry for drawing a line between two points using a rotated rectangle. */
export function lineSegment(x1: number, y1: number, x2: number, y2: number) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  return {
    cx: (x1 + x2) / 2,
    cy: (y1 + y2) / 2,
    length: Math.hypot(dx, dy),
    angle: Math.atan2(dy, dx),
  };
}
