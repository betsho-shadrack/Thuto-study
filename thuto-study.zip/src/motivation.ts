import { getSetting, setSetting } from './db';
import { MESSAGES, chooseIndex } from './messages';

function parseList(raw: string | null): number[] {
  if (!raw) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v.filter((x): x is number => typeof x === 'number') : [];
  } catch {
    return [];
  }
}

/**
 * Returns the next motivational message. Which messages were already shown in
 * the current cycle is remembered in the local database (settings table), so
 * nothing repeats until the whole collection has been used. Works offline.
 */
export async function nextMessage(): Promise<string> {
  try {
    const seen = parseList(await getSetting('msg_seen'));
    const last = Number((await getSetting('msg_last')) ?? -1);
    const { index, seen: nextSeen } = chooseIndex(seen, last, MESSAGES.length, Math.random);
    await setSetting('msg_seen', JSON.stringify(nextSeen));
    await setSetting('msg_last', String(index));
    return MESSAGES[index];
  } catch {
    // Storage problem: still show something.
    return MESSAGES[Math.floor(Math.random() * MESSAGES.length)];
  }
}
