import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Category, Trend } from './stats';
import { Colors, useTheme } from './theme';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

export function trendLook(trend: Trend, colors: Colors): { icon: IconName; label: string; color: string } {
  switch (trend) {
    case 'improving':
      return { icon: 'arrow-up', label: 'Improving', color: colors.success };
    case 'declining':
      return { icon: 'arrow-down', label: 'Declining', color: colors.danger };
    case 'stable':
      return { icon: 'arrow-forward', label: 'Stable', color: colors.warning };
    default:
      return { icon: 'ellipse-outline', label: 'Add another test', color: colors.sub };
  }
}

export function categoryLook(cat: Category, colors: Colors): { icon: IconName; label: string; color: string } {
  switch (cat) {
    case 'improving':
      return { icon: 'arrow-up', label: 'Improving', color: colors.success };
    case 'attention':
      return { icon: 'alert-circle', label: 'Needs attention', color: colors.danger };
    default:
      return { icon: 'arrow-forward', label: 'Stable', color: colors.warning };
  }
}

/** Arrow + word, coloured: up/green, flat/amber, down/red. */
export function TrendBadge({ trend, large }: { trend: Trend; large?: boolean }) {
  const { colors } = useTheme();
  const look = trendLook(trend, colors);
  return (
    <View
      accessibilityLabel={`Trend: ${look.label}`}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start',
        backgroundColor: `${look.color}22`,
        borderRadius: 999,
        paddingVertical: large ? 6 : 3,
        paddingHorizontal: large ? 12 : 8,
      }}
    >
      <Ionicons name={look.icon} size={large ? 18 : 14} color={look.color} />
      <Text style={{ color: look.color, fontWeight: '700', fontSize: large ? 15 : 12, marginLeft: 4 }}>{look.label}</Text>
    </View>
  );
}

/** A small number-and-label tile, used on the Scores dashboard and subject details. */
export function StatBox({ label, value, tint }: { label: string; value: string; tint?: string }) {
  const { colors } = useTheme();
  return (
    <View
      accessibilityLabel={`${label}: ${value}`}
      style={{
        flex: 1,
        marginHorizontal: 4,
        marginBottom: 8,
        backgroundColor: colors.input,
        borderRadius: 14,
        paddingVertical: 10,
        paddingHorizontal: 8,
        alignItems: 'center',
      }}
    >
      <Text style={{ fontSize: 20, fontWeight: '800', color: tint ?? colors.text }}>{value}</Text>
      <Text style={{ fontSize: 11, color: colors.sub, marginTop: 2, textAlign: 'center' }}>{label}</Text>
    </View>
  );
}
