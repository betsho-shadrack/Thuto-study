import React, { useEffect, useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Subject, addSubject, deleteSubject, getSetting, listSubjects, resetAll, setSetting } from '../src/db';
import { GRADES, STUDY_TIMES, parseList } from '../src/prefs';
import { useQuery } from '../src/store';
import { Mode, SUBJECT_COLORS, useTheme } from '../src/theme';
import { useTour } from '../src/tour/context';
import { TourTarget } from '../src/tour/TourTarget';
import { Button, Card, Chip, Dot, Field, FormScreen, Label, SectionTitle, Segmented } from '../src/ui';

export default function Settings() {
  const { colors, mode, setMode } = useTheme();
  const router = useRouter();
  const tour = useTour();
  const subjects = useQuery<Subject[]>(listSubjects, []).data;

  const [name, setName] = useState('');
  const [savedName, setSavedName] = useState('');
  const [family, setFamily] = useState('');
  const [school, setSchool] = useState('');
  const [grade, setGrade] = useState<string | null>(null);
  const [times, setTimes] = useState<string[]>([]);
  const [newSubject, setNewSubject] = useState('');
  const [color, setColor] = useState(SUBJECT_COLORS[0]);

  useEffect(() => {
    getSetting('name').then((v) => {
      setName(v ?? '');
      setSavedName(v ?? '');
    });
    getSetting('family_name').then((v) => setFamily(v ?? ''));
    getSetting('school').then((v) => setSchool(v ?? ''));
    getSetting('grade').then((v) => setGrade(v || null));
    getSetting('study_times').then((v) => setTimes(parseList(v)));
  }, []);

  const saveName = async () => {
    await setSetting('name', name.trim());
    setSavedName(name.trim());
  };

  const pickGrade = async (g: string) => {
    const next = grade === g ? null : g;
    setGrade(next);
    await setSetting('grade', next ?? '');
  };

  const toggleTime = async (key: string) => {
    const next = times.includes(key) ? times.filter((t) => t !== key) : [...times, key];
    setTimes(next);
    await setSetting('study_times', JSON.stringify(next));
  };

  const add = async () => {
    const v = newSubject.trim();
    if (!v) return;
    if (subjects.some((s) => s.name.toLowerCase() === v.toLowerCase())) {
      Alert.alert('Already added', `${v} is already in your subjects.`);
      return;
    }
    await addSubject(v, color);
    setNewSubject('');
    setColor(SUBJECT_COLORS[(subjects.length + 1) % SUBJECT_COLORS.length]);
  };

  const remove = (s: Subject) =>
    Alert.alert(
      `Remove ${s.name}?`,
      'Its test scores will be deleted. Tasks, exams and classes using it keep their data but lose the subject tag.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: () => deleteSubject(s.id) },
      ]
    );

  const reset = () =>
    Alert.alert('Erase everything?', 'All to dos, exams, study timetable, recorded study, test scores and subjects on this phone will be deleted.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Erase',
        style: 'destructive',
        onPress: async () => {
          await resetAll();
          router.replace('/onboarding');
        },
      },
    ]);

  return (
    <FormScreen>
      <Field label="Your name" value={name} onChangeText={setName} onBlur={saveName} onSubmitEditing={saveName} placeholder="Your name" autoCapitalize="words" />
      {name.trim() !== savedName ? <Button title="Save name" variant="soft" onPress={saveName} style={{ marginTop: -6, marginBottom: 12 }} /> : null}
      <Field label="Family name (surname)" value={family} onChangeText={setFamily} onBlur={() => setSetting('family_name', family.trim())} placeholder="Your family name" autoCapitalize="words" />
      <Field label="School" value={school} onChangeText={setSchool} onBlur={() => setSetting('school', school.trim())} placeholder="Your school" autoCapitalize="words" />

      <Label>Grade / Form</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {GRADES.map((g) => (
          <Chip key={g} label={g} selected={grade === g} onPress={() => pickGrade(g)} />
        ))}
      </View>

      <TourTarget id="settings-subjects">
        <SectionTitle>Subjects</SectionTitle>
        {subjects.length === 0 ? (
          <Text style={{ color: colors.sub, marginBottom: 10 }}>No subjects yet. Add your first one below.</Text>
        ) : (
          subjects.map((s) => (
            <Card key={s.id} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 10 }}>
              <Dot color={s.color} size={12} />
              <Text style={{ flex: 1, marginLeft: 12, fontSize: 16, color: colors.text, fontWeight: '600' }}>{s.name}</Text>
              <Pressable onPress={() => remove(s)} hitSlop={10} accessibilityRole="button" accessibilityLabel={`Remove ${s.name}`}>
                <Ionicons name="trash-outline" size={20} color={colors.danger} />
              </Pressable>
            </Card>
          ))
        )}

        <Field label="Add a subject" value={newSubject} onChangeText={setNewSubject} placeholder="e.g. Setswana" onSubmitEditing={add} returnKeyType="done" />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 }}>
          {SUBJECT_COLORS.map((c) => (
            <Pressable
              key={c}
              onPress={() => setColor(c)}
              style={{
                width: 34,
                height: 34,
                borderRadius: 17,
                backgroundColor: c,
                marginRight: 10,
                marginBottom: 10,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: color === c ? 3 : 0,
                borderColor: colors.text,
              }}
            >
              {color === c ? <Ionicons name="checkmark" size={18} color="#FFFFFF" /> : null}
            </Pressable>
          ))}
        </View>
        <Button title="Add subject" icon="add" variant="soft" onPress={add} disabled={!newSubject.trim()} />
      </TourTarget>

      <SectionTitle>Appearance</SectionTitle>
      <Segmented<Mode>
        value={mode}
        onChange={setMode}
        options={[
          { key: 'system', label: 'Auto' },
          { key: 'light', label: 'Light' },
          { key: 'dark', label: 'Dark' },
        ]}
      />

      <SectionTitle>Study preferences</SectionTitle>
      <Label>When do you like to study?</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {STUDY_TIMES.map((t) => (
          <Chip key={t.key} label={t.label} selected={times.includes(t.key)} onPress={() => toggleTime(t.key)} />
        ))}
      </View>

      <TourTarget id="settings-help">
        <SectionTitle>Help</SectionTitle>
        <Card>
          <Text style={{ color: colors.text, fontWeight: '700', fontSize: 16 }}>New to Thuto Study?</Text>
          <Text style={{ color: colors.sub, marginTop: 4, marginBottom: 12, lineHeight: 20 }}>
            Take the quick tour again to see where everything is.
          </Text>
          <Button title="Replay app tour" icon="play-circle" onPress={() => tour.start({ replay: true })} />
        </Card>
      </TourTarget>

      <SectionTitle>Data</SectionTitle>
      <Button title="Erase all data" variant="danger" onPress={reset} />

      <Text style={{ color: colors.sub, textAlign: 'center', marginTop: 28, fontSize: 12 }}>
        Thuto Study 1.0.0 | All your data is stored privately on this phone and works offline.
      </Text>
    </FormScreen>
  );
}
