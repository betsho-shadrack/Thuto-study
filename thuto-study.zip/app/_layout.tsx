import React, { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { getDb } from '../src/db';
import { Splash } from '../src/Splash';
import { ThemeProvider, useTheme } from '../src/theme';
import { TourProvider } from '../src/tour/TourProvider';

function Navigator() {
  const { colors, isDark } = useTheme();
  return (
    <>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: colors.card },
          headerTintColor: colors.text,
          headerShadowVisible: false,
          contentStyle: { backgroundColor: colors.bg },
        }}
      >
        <Stack.Screen name="index" options={{ headerShown: false }} />
        <Stack.Screen name="onboarding" options={{ headerShown: false, gestureEnabled: false }} />
        <Stack.Screen name="setup" options={{ headerShown: false, gestureEnabled: false }} />
        <Stack.Screen name="ready" options={{ headerShown: false, gestureEnabled: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="task-edit" options={{ title: 'Task', presentation: 'modal' }} />
        <Stack.Screen name="exam-edit" options={{ title: 'Exam', presentation: 'modal' }} />
        <Stack.Screen name="class-edit" options={{ title: 'Class', presentation: 'modal' }} />
        <Stack.Screen name="test-edit" options={{ title: 'Test', presentation: 'modal' }} />
        <Stack.Screen name="subject-scores" options={{ title: 'Subject' }} />
        <Stack.Screen name="settings" options={{ title: 'Settings' }} />
      </Stack>
    </>
  );
}

export default function RootLayout() {
  const [dbReady, setDbReady] = useState(false);
  const [splashDone, setSplashDone] = useState(false);

  useEffect(() => {
    getDb()
      .catch((e) => console.warn('Database failed to open', e))
      .finally(() => setDbReady(true));
  }, []);

  // Logo, name and a motivational message, all bundled in the app (no network).
  if (!splashDone) return <Splash dbReady={dbReady} onDone={() => setSplashDone(true)} />;

  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <TourProvider>
          <Navigator />
        </TourProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
