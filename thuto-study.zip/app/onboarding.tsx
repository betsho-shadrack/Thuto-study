import React from 'react';
import { Image, ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { setSetting } from '../src/db';
import { useTheme } from '../src/theme';
import { useTour } from '../src/tour/context';
import { Button } from '../src/ui';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

const HIGHLIGHTS: { icon: IconName; title: string; text: string }[] = [
  { icon: 'calendar', title: 'Plan', text: 'Study Timetable, Exam Timetable and To Do' },
  { icon: 'timer', title: 'Record Study', text: 'Record your study time' },
  { icon: 'trophy', title: 'Improve', text: 'Test scores, trends and graphs' },
];

/** Welcome screen, shown on the very first launch. */
export default function Welcome() {
  const { colors } = useTheme();
  const router = useRouter();
  const tour = useTour();

  const begin = () => {
    router.replace('/(tabs)');
    tour.start();
  };

  const skip = async () => {
    try {
      await setSetting('onboarding_state', 'skipped');
    } catch (e) {
      console.warn('Could not save onboarding state', e);
    }
    router.replace('/(tabs)');
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, padding: 24, justifyContent: 'center' }}>
        <View style={{ alignItems: 'center', marginBottom: 24 }}>
          <Image source={require('../assets/icon.png')} style={{ width: 104, height: 104, borderRadius: 28 }} />
          <Text style={{ fontSize: 32, fontWeight: '800', color: colors.text, marginTop: 18 }}>Thuto Study</Text>
          <Text style={{ fontSize: 16, color: colors.sub, marginTop: 6, textAlign: 'center' }}>
            Plan your study, stay focused and watch your marks improve.
          </Text>
        </View>

        <View
          style={{
            backgroundColor: colors.primarySoft,
            borderRadius: 18,
            padding: 16,
            marginBottom: 20,
          }}
        >
          <Text style={{ fontSize: 17, fontWeight: '700', color: colors.primary, textAlign: 'center', lineHeight: 24 }}>
            Welcome to Thuto Study. Let's get you set up for smarter studying.
          </Text>
        </View>

        <View style={{ marginBottom: 26 }}>
          {HIGHLIGHTS.map((h) => (
            <View key={h.title} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
              <View
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 14,
                  backgroundColor: colors.card,
                  borderWidth: 1,
                  borderColor: colors.border,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Ionicons name={h.icon} size={22} color={colors.primary} />
              </View>
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{ fontWeight: '800', color: colors.text, fontSize: 16 }}>{h.title}</Text>
                <Text style={{ color: colors.sub }}>{h.text}</Text>
              </View>
            </View>
          ))}
        </View>

        <Button title="Let's Get Started" icon="arrow-forward" onPress={begin} />
        <Button title="Skip Tour" variant="soft" onPress={skip} style={{ marginTop: 10 }} />
        <Text style={{ color: colors.sub, textAlign: 'center', fontSize: 12, marginTop: 14 }}>
          The tour takes about a minute. You can replay it any time from Settings.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}
