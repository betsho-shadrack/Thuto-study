import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { addSubject, listSubjects, setSetting } from '../src/db';
import { GRADES, STUDY_TIMES } from '../src/prefs';
import { SUBJECT_COLORS, useTheme } from '../src/theme';
import { Button, Chip, Label } from '../src/ui';

const SUGGESTED = [
  'Mathematics', 'English', 'Setswana', 'Science', 'Social Studies',
  'Religious Education', 'Agriculture', 'Business Studies', 'Computer Studies',
  'Art', 'Physics', 'Chemistry', 'Biology', 'History', 'Geography',
];

/** Optional quick setup after the tour. Every field can be left empty. */
export default function Setup() {
  const { colors } = useTheme();
  const router = useRouter();
  const [name, setName] = useState('');
  const [family, setFamily] = useState('');
  const [school, setSchool] = useState('');
  const [grade, setGrade] = useState<string | null>(null);
  const [picked, setPicked] = useState<string[]>([]);
  const [custom, setCustom] = useState('');
  const [times, setTimes] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  const toggle = (list: string[], v: string) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);

  const addCustom = () => {
    const v = custom.trim();
    if (!v) return;
    if (!picked.some((p) => p.toLowerCase() === v.toLowerCase())) setPicked((p) => [...p, v]);
    setCustom('');
  };

  const save = async () => {
    setSaving(true);
    try {
      if (name.trim()) await setSetting('name', name.trim());
      if (family.trim()) await setSetting('family_name', family.trim());
      if (school.trim()) await setSetting('school', school.trim());
      if (grade) await setSetting('grade', grade);
      if (times.length) await setSetting('study_times', JSON.stringify(times));
      const existing = (await listSubjects()).map((s) => s.name.toLowerCase());
      let colorIndex = existing.length;
      for (const s of picked) {
        if (existing.includes(s.toLowerCase())) continue;
        await addSubject(s, SUBJECT_COLORS[colorIndex % SUBJECT_COLORS.length]);
        colorIndex += 1;
      }
      router.replace('/ready');
    } catch (e) {
      setSaving(false);
      Alert.alert('Something went wrong', 'Could not save your setup. You can set everything up later in Settings.');
    }
  };

  const everything = [...SUGGESTED, ...picked.filter((p) => !SUGGESTED.includes(p))];
  const anything = name.trim() || family.trim() || school.trim() || grade || picked.length > 0 || times.length > 0;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
          <Text style={{ fontSize: 28, fontWeight: '800', color: colors.text }}>Quick setup</Text>
          <Text style={{ color: colors.sub, marginTop: 4, marginBottom: 20, lineHeight: 21 }}>
            Optional. Fill in what you like and skip the rest. You can change everything later in Settings.
          </Text>

          {[
            { label: 'Your name', value: name, set: setName, ph: 'What should we call you?' },
            { label: 'Family name (surname)', value: family, set: setFamily, ph: 'Your family name' },
            { label: 'School', value: school, set: setSchool, ph: 'Your school (optional)' },
          ].map((f) => (
            <View key={f.label}>
              <Label>{f.label}</Label>
              <TextInput
                value={f.value}
                onChangeText={f.set}
                placeholder={f.ph}
                placeholderTextColor={colors.sub}
                autoCapitalize="words"
                style={{
                  backgroundColor: colors.card,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 12,
                  paddingHorizontal: 14,
                  paddingVertical: 12,
                  fontSize: 16,
                  color: colors.text,
                  marginBottom: 16,
                }}
              />
            </View>
          ))}

          <Label>Grade / Form</Label>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 12 }}>
            {GRADES.map((g) => (
              <Chip key={g} label={g} selected={grade === g} onPress={() => setGrade(grade === g ? null : g)} />
            ))}
          </View>

          <Label>Your subjects</Label>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {everything.map((s) => (
              <Chip key={s} label={s} selected={picked.includes(s)} onPress={() => setPicked(toggle(picked, s))} />
            ))}
          </View>
          <View style={{ flexDirection: 'row', marginTop: 4, marginBottom: 20 }}>
            <TextInput
              value={custom}
              onChangeText={setCustom}
              placeholder="Add another subject"
              placeholderTextColor={colors.sub}
              onSubmitEditing={addCustom}
              returnKeyType="done"
              style={{
                flex: 1,
                backgroundColor: colors.card,
                borderWidth: 1,
                borderColor: colors.border,
                borderRadius: 12,
                paddingHorizontal: 14,
                paddingVertical: 10,
                fontSize: 16,
                color: colors.text,
                marginRight: 8,
              }}
            />
            <Button title="Add" variant="soft" onPress={addCustom} style={{ paddingVertical: 10 }} />
          </View>

          <Label>When do you like to study?</Label>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 24 }}>
            {STUDY_TIMES.map((t) => (
              <Chip key={t.key} label={t.label} selected={times.includes(t.key)} onPress={() => setTimes(toggle(times, t.key))} />
            ))}
          </View>

          <Button title={saving ? 'Saving...' : anything ? 'Save and continue' : 'Continue'} onPress={save} disabled={saving} />
          <Button title="Skip for now" variant="soft" onPress={() => router.replace('/ready')} disabled={saving} style={{ marginTop: 10 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
