import React, { useEffect, useRef, useState } from 'react';
import { Alert, Text, Vibration, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { StudySession, Subject, addSession, listSubjects, minutesByDay, recentSessions } from '../../src/db';
import { useQuery } from '../../src/store';
import { TourTarget } from '../../src/tour/TourTarget';
import { useTheme } from '../../src/theme';
import { Bar, Button, Card, Chip, Dot, Label, Screen, SectionTitle } from '../../src/ui';
import { formatMinutes, formatDate, todayISO } from '../../src/dates';

const PRESETS = [15, 25, 45, 60];

const mmss = (secs: number) => {
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
};

export default function Focus() {
  const { colors } = useTheme();
  const subjects = useQuery<Subject[]>(listSubjects, []).data;
  const recent = useQuery<StudySession[]>(() => recentSessions(5), []).data;
  const todayMinutes = useQuery(() => minutesByDay(todayISO()), [] as { day: string; minutes: number }[]).data.reduce(
    (s, r) => s + r.minutes,
    0
  );

  const [subjectId, setSubjectId] = useState<number | null>(null);
  const [minutes, setMinutes] = useState(25);
  const [remaining, setRemaining] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [started, setStarted] = useState(false);

  // Refs let the interval callback and finish() always see the latest values.
  const endAt = useRef(0);
  const totalSecs = useRef(25 * 60);
  const remainingRef = useRef(25 * 60);
  const subjectRef = useRef<number | null>(null);
  subjectRef.current = subjectId;

  const updateRemaining = (v: number) => {
    remainingRef.current = v;
    setRemaining(v);
  };

  const reset = (mins: number) => {
    setRunning(false);
    setStarted(false);
    totalSecs.current = mins * 60;
    updateRemaining(mins * 60);
  };

  const finish = async (completed: boolean) => {
    const elapsed = completed ? totalSecs.current : totalSecs.current - remainingRef.current;
    const done = completed ? Math.round(totalSecs.current / 60) : Math.floor(elapsed / 60);
    setRunning(false);
    setStarted(false);
    updateRemaining(totalSecs.current);
    if (done >= 1) {
      await addSession(subjectRef.current, done);
      if (completed) Vibration.vibrate([0, 400, 200, 400]);
      Alert.alert(completed ? 'Session complete' : 'Session saved', `${formatMinutes(done)} of study recorded. Nice work.`);
    } else {
      Alert.alert('Session too short', 'Sessions under one minute are not recorded.');
    }
  };

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      const left = Math.max(0, Math.round((endAt.current - Date.now()) / 1000));
      updateRemaining(left);
      if (left <= 0) {
        clearInterval(id);
        finish(true);
      }
    }, 500);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);

  const start = () => {
    if (!started) {
      totalSecs.current = minutes * 60;
      updateRemaining(minutes * 60);
    }
    endAt.current = Date.now() + remainingRef.current * 1000;
    setStarted(true);
    setRunning(true);
  };

  const pause = () => {
    setRunning(false);
  };

  const chooseMinutes = (m: number) => {
    setMinutes(m);
    if (!started) reset(m);
  };

  const elapsed = totalSecs.current - remaining;

  return (
    <Screen title="Record Study" subtitle={`${formatMinutes(todayMinutes)} of study recorded today`}>
      <TourTarget id="focus-timer">
      <Card style={{ alignItems: 'center', paddingVertical: 28 }}>
        <Text style={{ fontSize: 68, fontWeight: '800', color: colors.text, fontVariant: ['tabular-nums'] }}>
          {mmss(remaining)}
        </Text>
        <View style={{ width: '90%', marginTop: 12 }}>
          <Bar value={elapsed} max={totalSecs.current} />
        </View>
        <Text style={{ color: colors.sub, marginTop: 10 }}>
          {running ? 'Recording your study. Stay with it!' : started ? 'Paused' : 'Ready to record your study'}
        </Text>
      </Card>
      </TourTarget>

      {!started ? (
        <>
          <Label>Length</Label>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {PRESETS.map((p) => (
              <Chip key={p} label={`${p} min`} selected={minutes === p} onPress={() => chooseMinutes(p)} />
            ))}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 14 }}>
            <Button title="-5" variant="soft" onPress={() => chooseMinutes(Math.max(5, minutes - 5))} style={{ paddingVertical: 8, paddingHorizontal: 16 }} />
            <Text style={{ marginHorizontal: 16, fontSize: 16, fontWeight: '700', color: colors.text }}>{minutes} min</Text>
            <Button title="+5" variant="soft" onPress={() => chooseMinutes(Math.min(180, minutes + 5))} style={{ paddingVertical: 8, paddingHorizontal: 16 }} />
          </View>
        </>
      ) : null}

      <Label>Subject</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 12 }}>
        <Chip label="General" selected={subjectId === null} color={colors.sub} onPress={() => setSubjectId(null)} />
        {subjects.map((s) => (
          <Chip key={s.id} label={s.name} color={s.color} selected={subjectId === s.id} onPress={() => setSubjectId(s.id)} />
        ))}
      </View>

      {running ? (
        <Button title="Pause" icon="pause" variant="soft" onPress={pause} />
      ) : (
        <Button title={started ? 'Resume' : 'Start recording'} icon="play" onPress={start} />
      )}
      {started ? (
        <View style={{ flexDirection: 'row', marginTop: 10 }}>
          <Button title="Stop and save" icon="checkmark" variant="soft" onPress={() => finish(false)} style={{ flex: 1, marginRight: 8 }} />
          <Button
            title="Discard"
            variant="danger"
            onPress={() =>
              Alert.alert('Discard session?', 'This session will not be recorded.', [
                { text: 'Keep going', style: 'cancel' },
                { text: 'Discard', style: 'destructive', onPress: () => reset(minutes) },
              ])
            }
            style={{ flex: 1 }}
          />
        </View>
      ) : null}

      <Text style={{ color: colors.sub, fontSize: 12, marginTop: 12, textAlign: 'center' }}>
        Keep the app open while you record your study. If you switch apps, the timer catches up when you return.
      </Text>

      <SectionTitle>Recorded study</SectionTitle>
      {recent.length === 0 ? (
        <Card>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Ionicons name="hourglass-outline" size={20} color={colors.sub} />
            <Text style={{ color: colors.sub, marginLeft: 10 }}>Your finished sessions will show up here.</Text>
          </View>
        </Card>
      ) : (
        recent.map((r) => (
          <Card key={r.id} style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Dot color={r.subject_color} />
            <Text style={{ flex: 1, marginLeft: 10, color: colors.text, fontWeight: '600' }}>
              {r.subject_name ?? 'General'}
            </Text>
            <Text style={{ color: colors.sub }}>
              {formatMinutes(r.minutes)} | {formatDate(r.day)}
            </Text>
          </Card>
        ))
      )}
    </Screen>
  );
}
