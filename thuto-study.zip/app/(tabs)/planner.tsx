import React, { useState } from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ClassSlot, Exam, listClasses, listExams } from '../../src/db';
import { useQuery } from '../../src/store';
import { TourTarget } from '../../src/tour/TourTarget';
import { useTheme } from '../../src/theme';
import { Card, Dot, Empty, Fab, Screen, Segmented } from '../../src/ui';
import { DAYS, DAYS_LONG, daysBetween, formatDate, todayISO, weekdayIndex } from '../../src/dates';

type View_ = 'timetable' | 'exams';

export default function Planner() {
  const { colors } = useTheme();
  const router = useRouter();
  const today = todayISO();
  const [view, setView] = useState<View_>('timetable');
  const [day, setDay] = useState(weekdayIndex(today));

  const classes = useQuery<ClassSlot[]>(() => listClasses(), []).data;
  const exams = useQuery<Exam[]>(listExams, []).data;

  const dayClasses = classes.filter((c) => c.day === day);
  const upcoming = exams.filter((e) => e.date >= today);
  const past = exams.filter((e) => e.date < today).reverse();

  const renderExam = (e: Exam, isPast: boolean) => {
    const left = daysBetween(today, e.date);
    return (
      <Card
        key={e.id}
        onPress={() => router.push({ pathname: '/exam-edit', params: { id: String(e.id) } })}
        style={{ flexDirection: 'row', alignItems: 'center', opacity: isPast ? 0.55 : 1 }}
      >
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '700', color: colors.text }}>{e.title}</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 4, flexWrap: 'wrap' }}>
            {e.subject_name ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', marginRight: 10 }}>
                <Dot color={e.subject_color} size={8} />
                <Text style={{ color: colors.sub, marginLeft: 5 }}>{e.subject_name}</Text>
              </View>
            ) : null}
            <Text style={{ color: colors.sub }}>
              {formatDate(e.date)}
              {e.time ? ` at ${e.time}` : ''}
              {e.venue ? `  |  ${e.venue}` : ''}
            </Text>
          </View>
        </View>
        {!isPast ? (
          <View style={{ alignItems: 'center', minWidth: 54 }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: left <= 3 ? colors.danger : colors.primary }}>{left}</Text>
            <Text style={{ fontSize: 11, fontWeight: '700', color: colors.sub }}>{left === 1 ? 'DAY' : 'DAYS'}</Text>
          </View>
        ) : null}
      </Card>
    );
  };

  return (
    <Screen
      title={view === 'timetable' ? 'Study Timetable' : 'Exam Timetable'}
      subtitle={view === 'timetable' ? 'Your weekly study plan' : `${upcoming.length} upcoming exam${upcoming.length === 1 ? '' : 's'}`}
      fab={
        <Fab
          onPress={() =>
            view === 'timetable'
              ? router.push({ pathname: '/class-edit', params: { day: String(day) } })
              : router.push('/exam-edit')
          }
        />
      }
    >
      <TourTarget id="planner-main">
        <Segmented<View_>
          value={view}
          onChange={setView}
          options={[
            { key: 'timetable', label: 'Study Timetable' },
            { key: 'exams', label: 'Exam Timetable' },
          ]}
        />
      </TourTarget>

      {view === 'timetable' ? (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 14, marginBottom: 6 }}>
            {DAYS.map((d, i) => {
              const active = i === day;
              const count = classes.filter((c) => c.day === i).length;
              return (
                <Pressable
                  key={d}
                  onPress={() => setDay(i)}
                  style={{
                    width: 56,
                    paddingVertical: 10,
                    borderRadius: 14,
                    alignItems: 'center',
                    marginRight: 8,
                    backgroundColor: active ? colors.primary : colors.card,
                    borderWidth: 1,
                    borderColor: active ? colors.primary : colors.border,
                  }}
                >
                  <Text style={{ fontWeight: '700', color: active ? colors.primaryText : colors.text }}>{d}</Text>
                  <Text style={{ fontSize: 11, color: active ? colors.primaryText : colors.sub, marginTop: 2 }}>
                    {count === 0 ? '-' : `${count} session${count === 1 ? '' : 's'}`}
                  </Text>
                </Pressable>
              );
            })}
          </ScrollView>

          <Text style={{ fontSize: 16, fontWeight: '700', color: colors.text, marginVertical: 8 }}>
            {DAYS_LONG[day]}
            {day === weekdayIndex(today) ? ' (today)' : ''}
          </Text>

          {dayClasses.length === 0 ? (
            <Empty icon="school-outline" text={`Nothing planned for ${DAYS_LONG[day]}. Tap + to add a study session.`} />
          ) : (
            dayClasses.map((c) => (
              <Card
                key={c.id}
                onPress={() => router.push({ pathname: '/class-edit', params: { id: String(c.id) } })}
                style={{ flexDirection: 'row', alignItems: 'center' }}
              >
                <View style={{ width: 4, alignSelf: 'stretch', borderRadius: 2, backgroundColor: c.subject_color ?? colors.sub, marginRight: 12 }} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 16, fontWeight: '700', color: colors.text }}>
                    {c.subject_name ?? (c.title || 'Study session')}
                  </Text>
                  {c.subject_name && c.title ? <Text style={{ color: colors.sub, marginTop: 1 }}>{c.title}</Text> : null}
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={{ fontWeight: '700', color: colors.text }}>{c.start}</Text>
                  <Text style={{ color: colors.sub }}>{c.end}</Text>
                  {c.room ? <Text style={{ color: colors.sub, fontSize: 12, marginTop: 2 }}>{c.room}</Text> : null}
                </View>
              </Card>
            ))
          )}
        </>
      ) : (
        <View style={{ marginTop: 14 }}>
          {upcoming.length === 0 && past.length === 0 ? (
            <Empty icon="document-text-outline" text="No exams on your Exam Timetable yet. Tap + to add one and watch the countdown." />
          ) : null}
          {upcoming.map((e) => renderExam(e, false))}
          {past.length > 0 ? (
            <Text style={{ fontSize: 14, fontWeight: '700', color: colors.sub, marginVertical: 8 }}>Past exams</Text>
          ) : null}
          {past.map((e) => renderExam(e, true))}
        </View>
      )}
    </Screen>
  );
}
