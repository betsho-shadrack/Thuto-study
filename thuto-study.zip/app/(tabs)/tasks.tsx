import React, { useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Subject, Task, listSubjects, listTasks, setTaskDone } from '../../src/db';
import { useQuery } from '../../src/store';
import { useTheme } from '../../src/theme';
import { Chip, Empty, Fab, Screen, Segmented } from '../../src/ui';
import { TaskRow } from '../../src/TaskRow';

type Filter = 'pending' | 'done' | 'all';

export default function Tasks() {
  const { colors } = useTheme();
  const router = useRouter();
  const [filter, setFilter] = useState<Filter>('pending');
  const [subjectId, setSubjectId] = useState<number | null>(null);

  const tasks = useQuery<Task[]>(listTasks, []).data;
  const subjects = useQuery<Subject[]>(listSubjects, []).data;

  const shown = tasks.filter((t) => {
    if (filter === 'pending' && t.done === 1) return false;
    if (filter === 'done' && t.done === 0) return false;
    if (subjectId !== null && t.subject_id !== subjectId) return false;
    return true;
  });
  const pendingCount = tasks.filter((t) => t.done === 0).length;

  return (
    <Screen
      title="To Do"
      subtitle={`${pendingCount} to do`}
      fab={<Fab tourId="tasks-add" onPress={() => router.push('/task-edit')} />}
    >
      <Segmented<Filter>
        value={filter}
        onChange={setFilter}
        options={[
          { key: 'pending', label: 'To do' },
          { key: 'done', label: 'Done' },
          { key: 'all', label: 'All' },
        ]}
      />

      {subjects.length > 0 ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 12, marginBottom: 4 }}>
          <Chip label="All subjects" selected={subjectId === null} color={colors.sub} onPress={() => setSubjectId(null)} />
          {subjects.map((s) => (
            <Chip
              key={s.id}
              label={s.name}
              color={s.color}
              selected={subjectId === s.id}
              onPress={() => setSubjectId(subjectId === s.id ? null : s.id)}
            />
          ))}
        </ScrollView>
      ) : null}

      <View style={{ marginTop: 12 }}>
        {shown.length === 0 ? (
          <Empty
            icon={filter === 'done' ? 'trophy-outline' : 'checkmark-done-outline'}
            text={
              filter === 'done'
                ? 'Completed tasks will appear here.'
                : 'Your to do list is empty. Tap the + button to add homework, revision or projects.'
            }
          />
        ) : (
          shown.map((t) => (
            <TaskRow
              key={t.id}
              task={t}
              onToggle={() => setTaskDone(t.id, t.done === 0)}
              onPress={() => router.push({ pathname: '/task-edit', params: { id: String(t.id) } })}
            />
          ))
        )}
      </View>
      <Text style={{ color: colors.sub, fontSize: 12, textAlign: 'center', marginTop: 8 }}>
        Tap a task to edit it. Tap the box to mark it done.
      </Text>
    </Screen>
  );
}
