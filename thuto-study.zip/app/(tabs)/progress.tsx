import React, { useMemo, useState } from 'react';
import { Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import {
  Subject, TestRow, listSubjects, listTests, minutesByDay, minutesBySubject, sessionDays, taskCounts, tasksDoneSince,
} from '../../src/db';
import { useQuery } from '../../src/store';
import { useTheme } from '../../src/theme';
import { TourTarget } from '../../src/tour/TourTarget';
import { SubjectStats, categorize, computeStats, formatPercent, summarize } from '../../src/stats';
import { StatBox, TrendBadge } from '../../src/scoreUi';
import { Bar, Card, Dot, Empty, Screen, SectionTitle, Segmented } from '../../src/ui';

type Mode_ = 'study' | 'scores';
import { DAYS, addDays, computeStreak, formatMinutes, startOfWeek, todayISO, weekdayIndex } from '../../src/dates';

export default function Progress() {
  const { colors } = useTheme();
  const [mode, setMode] = useState<Mode_>('study');
  const today = todayISO();
  const weekStart = startOfWeek(today);

  const byDay = useQuery(() => minutesByDay(weekStart), [] as { day: string; minutes: number }[], [weekStart]).data;
  const bySubject = useQuery(
    () => minutesBySubject(weekStart),
    [] as { name: string | null; color: string | null; minutes: number }[],
    [weekStart]
  ).data;
  const counts = useQuery(taskCounts, { total: 0, done: 0 }).data;
  const doneThisWeek = useQuery(() => tasksDoneSince(weekStart), 0, [weekStart]).data;
  const days = useQuery<string[]>(sessionDays, []).data;
  const router = useRouter();
  const subjects = useQuery<Subject[]>(listSubjects, []).data;
  const tests = useQuery<TestRow[]>(() => listTests(), []).data;

  // Best subject and subjects that need attention, from the Test Scores data.
  const snapshot = useMemo(() => {
    const rows = subjects
      .map((s) => ({ name: s.name, stats: computeStats(tests.filter((t) => t.subject_id === s.id)) }))
      .filter((r): r is { name: string; stats: SubjectStats } => r.stats !== null);
    const best = rows.length ? [...rows].sort((a, b) => b.stats.average - a.stats.average)[0] : null;
    const attention = rows.filter((r) => categorize(r.stats) === 'attention');
    return { best, attention, any: rows.length > 0, rows };
  }, [subjects, tests]);
  const overall = summarize(snapshot.rows.map((r) => r.stats));

  const dayMinutes = DAYS.map((_, i) => {
    const iso = addDays(weekStart, i);
    return { iso, minutes: byDay.find((d) => d.day === iso)?.minutes ?? 0 };
  });
  const weekTotal = dayMinutes.reduce((s, d) => s + d.minutes, 0);
  const maxDay = Math.max(30, ...dayMinutes.map((d) => d.minutes));
  const subjectMax = Math.max(1, ...bySubject.map((s) => s.minutes));
  const rate = counts.total === 0 ? 0 : Math.round((counts.done / counts.total) * 100);
  const streak = computeStreak(days);
  const todayIdx = weekdayIndex(today);

  return (
    <Screen title="Progress" subtitle={mode === 'study' ? 'Study time this week' : 'Test scores across subjects'}>
      <TourTarget id="progress-week">
        <Segmented<Mode_>
          value={mode}
          onChange={setMode}
          options={[
            { key: 'study', label: 'Study Time' },
            { key: 'scores', label: 'Test Scores' },
          ]}
        />
      </TourTarget>

      {mode === 'scores' ? (
        <>
          <Card style={{ marginTop: 14 }}>
            <Text style={{ fontSize: 13, fontWeight: '700', color: colors.sub }}>Overall average</Text>
            <Text style={{ fontSize: 36, fontWeight: '800', color: colors.text }}>
              {overall.tracked > 0 ? formatPercent(overall.average) : '--'}
            </Text>
            <View style={{ flexDirection: 'row', marginHorizontal: -4, marginTop: 6 }}>
              <StatBox label="Improving" value={String(overall.improving)} tint={colors.success} />
              <StatBox label="Stable" value={String(overall.stable)} tint={colors.warning} />
              <StatBox label="Needs attention" value={String(overall.attention)} tint={colors.danger} />
            </View>
          </Card>
          <SectionTitle>Subjects</SectionTitle>
          {snapshot.rows.length === 0 ? (
            <Empty icon="trophy-outline" text="Add test scores in the Scores tab to see your progress here." />
          ) : (
            snapshot.rows.map((r) => {
              const subj = subjects.find((s) => s.name === r.name);
              return (
                <Card
                  key={r.name}
                  onPress={subj ? () => router.push({ pathname: '/subject-scores', params: { id: String(subj.id) } }) : undefined}
                >
                  <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                    <Dot color={subj?.color ?? null} />
                    <Text style={{ flex: 1, marginLeft: 8, color: colors.text, fontWeight: '700' }}>{r.name}</Text>
                    <Text style={{ color: colors.text, fontWeight: '800', fontSize: 18 }}>{formatPercent(r.stats.latest)}</Text>
                  </View>
                  <Bar value={r.stats.latest} max={100} color={subj?.color ?? colors.primary} />
                  <View style={{ marginTop: 8 }}>
                    <TrendBadge trend={r.stats.trend} />
                  </View>
                </Card>
              );
            })
          )}
        </>
      ) : (
      <>
      <View style={{ flexDirection: 'row', marginHorizontal: -4, marginTop: 14 }}>
        {[
          { label: 'Study time', value: formatMinutes(weekTotal) },
          { label: 'To dos done', value: String(doneThisWeek) },
          { label: 'Day streak', value: String(streak) },
        ].map((s) => (
          <View
            key={s.label}
            style={{
              flex: 1,
              marginHorizontal: 4,
              backgroundColor: colors.card,
              borderRadius: 16,
              borderWidth: 1,
              borderColor: colors.border,
              padding: 12,
              alignItems: 'center',
            }}
          >
            <Text style={{ fontSize: 20, fontWeight: '800', color: colors.text }}>{s.value}</Text>
            <Text style={{ fontSize: 12, color: colors.sub, marginTop: 2 }}>{s.label}</Text>
          </View>
        ))}
      </View>

      <SectionTitle>Study minutes per day</SectionTitle>
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 150 }}>
          {dayMinutes.map((d, i) => {
            const h = d.minutes === 0 ? 4 : Math.max(8, Math.round((d.minutes / maxDay) * 110));
            const isToday = i === todayIdx;
            return (
              <View key={d.iso} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end' }}>
                <Text style={{ fontSize: 11, color: colors.sub, marginBottom: 4 }}>{d.minutes > 0 ? d.minutes : ''}</Text>
                <View
                  style={{
                    width: 22,
                    height: h,
                    borderRadius: 6,
                    backgroundColor: d.minutes === 0 ? colors.input : isToday ? colors.primary : colors.primarySoft,
                    borderWidth: d.minutes > 0 && !isToday ? 1 : 0,
                    borderColor: colors.primary,
                  }}
                />
                <Text style={{ fontSize: 12, marginTop: 6, color: isToday ? colors.primary : colors.sub, fontWeight: isToday ? '800' : '500' }}>
                  {DAYS[i].slice(0, 2)}
                </Text>
              </View>
            );
          })}
        </View>
      </Card>

      <SectionTitle>Time by subject</SectionTitle>
      {bySubject.length === 0 ? (
        <Empty icon="stats-chart-outline" text="Record some study to see where your time goes." />
      ) : (
        <Card>
          {bySubject.map((s, i) => (
            <View key={`${s.name}-${i}`} style={{ marginBottom: i === bySubject.length - 1 ? 0 : 14 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
                <Dot color={s.color} />
                <Text style={{ flex: 1, marginLeft: 8, color: colors.text, fontWeight: '600' }}>{s.name ?? 'General'}</Text>
                <Text style={{ color: colors.sub }}>{formatMinutes(s.minutes)}</Text>
              </View>
              <Bar value={s.minutes} max={subjectMax} color={s.color ?? colors.primary} />
            </View>
          ))}
        </Card>
      )}

      <SectionTitle>To do completion</SectionTitle>
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'baseline', marginBottom: 8 }}>
          <Text style={{ fontSize: 28, fontWeight: '800', color: colors.text }}>{rate}%</Text>
          <Text style={{ color: colors.sub, marginLeft: 8 }}>
            {counts.done} of {counts.total} to dos completed
          </Text>
        </View>
        <Bar value={counts.done} max={Math.max(1, counts.total)} color={colors.success} />
      </Card>

      <SectionTitle>Academic snapshot</SectionTitle>
      <Card onPress={() => router.navigate('/(tabs)/scores' as never)}>
        {snapshot.any && snapshot.best ? (
          <>
            <Text style={{ color: colors.sub, fontSize: 13, fontWeight: '700' }}>Best subject</Text>
            <Text style={{ color: colors.text, fontSize: 17, fontWeight: '800', marginBottom: 12 }}>
              {snapshot.best.name} ({formatPercent(snapshot.best.stats.average)} average)
            </Text>
            <Text style={{ color: colors.sub, fontSize: 13, fontWeight: '700' }}>Needs attention</Text>
            <Text style={{ color: snapshot.attention.length ? colors.danger : colors.success, fontSize: 17, fontWeight: '800' }}>
              {snapshot.attention.length ? snapshot.attention.map((r) => r.name).join(', ') : 'None right now. Nice work!'}
            </Text>
          </>
        ) : (
          <Text style={{ color: colors.sub }}>Add test scores to see your best subject and where to improve.</Text>
        )}
      </Card>
      </>
      )}
    </Screen>
  );
}
