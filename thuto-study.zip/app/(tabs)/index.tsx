import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import {
  ClassSlot, Exam, Task, getSetting, listClasses, listExams, listTasks,
  minutesByDay, sessionDays, setTaskDone,
} from '../../src/db';
import { useQuery } from '../../src/store';
import { TourTarget } from '../../src/tour/TourTarget';
import { useTheme } from '../../src/theme';
import { Button, Card, Dot, Empty, Screen, SectionTitle } from '../../src/ui';
import { TaskRow } from '../../src/TaskRow';
import {
  computeStreak, daysBetween, formatDate, formatMinutes, greeting, todayISO, weekdayIndex,
} from '../../src/dates';

function Stat({ icon, value, label, color }: { icon: React.ComponentProps<typeof Ionicons>['name']; value: string; label: string; color: string }) {
  const { colors } = useTheme();
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: colors.card,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: colors.border,
        padding: 12,
        marginHorizontal: 4,
        alignItems: 'center',
      }}
    >
      <Ionicons name={icon} size={22} color={color} />
      <Text style={{ fontSize: 20, fontWeight: '800', color: colors.text, marginTop: 4 }}>{value}</Text>
      <Text style={{ fontSize: 12, color: colors.sub }}>{label}</Text>
    </View>
  );
}

export default function Home() {
  const { colors } = useTheme();
  const router = useRouter();
  const today = todayISO();

  const name = useQuery<string | null>(() => getSetting('name'), null).data;
  const tasks = useQuery<Task[]>(listTasks, []).data;
  const exams = useQuery<Exam[]>(listExams, []).data;
  const classes = useQuery<ClassSlot[]>(() => listClasses(weekdayIndex(today)), [], [today]).data;
  const minutes = useQuery(() => minutesByDay(today), [] as { day: string; minutes: number }[], [today]).data;
  const days = useQuery<string[]>(sessionDays, []).data;

  const pending = tasks.filter((t) => t.done === 0);
  const dueNow = pending.filter((t) => t.due_date !== null && t.due_date <= today);
  const comingUp = pending.filter((t) => t.due_date !== null && t.due_date > today).slice(0, 3);
  const nextExam = exams.find((e) => e.date >= today);
  const focusToday = minutes.reduce((sum, m) => sum + m.minutes, 0);
  const streak = computeStreak(days);

  const openTask = (t: Task) => router.push({ pathname: '/task-edit', params: { id: String(t.id) } });

  return (
    <Screen
      title={`${greeting()}${name ? `, ${name.split(' ')[0]}` : ''}`}
      subtitle={formatDate(today)}
      eyebrow="Thuto Study"
      right={
        <Pressable onPress={() => router.push('/settings')} hitSlop={10} style={{ padding: 6 }}>
          <Ionicons name="settings-outline" size={26} color={colors.text} />
        </Pressable>
      }
    >
      <TourTarget id="home-overview">
      <View style={{ flexDirection: 'row', marginHorizontal: -4, marginTop: 8 }}>
        <Stat icon="alert-circle" value={String(dueNow.length)} label="Due now" color={dueNow.length ? colors.warning : colors.sub} />
        <Stat icon="timer" value={focusToday ? formatMinutes(focusToday) : '0'} label="Studied today" color={colors.primary} />
        <Stat icon="flame" value={`${streak}`} label="Day streak" color={streak ? '#F97316' : colors.sub} />
      </View>

      <View style={{ flexDirection: 'row', marginTop: 14 }}>
        <Button title="Add to do" icon="add" onPress={() => router.push('/task-edit')} style={{ flex: 1, marginRight: 8 }} />
        <Button title="Record study" icon="play" variant="soft" onPress={() => router.push('/timer')} style={{ flex: 1 }} />
      </View>
      </TourTarget>

      <SectionTitle>Due today and overdue</SectionTitle>
      {dueNow.length === 0 ? (
        <Card>
          <Text style={{ color: colors.sub }}>Nothing due. Enjoy the breathing room or get ahead below.</Text>
        </Card>
      ) : (
        dueNow.slice(0, 5).map((t) => (
          <TaskRow key={t.id} task={t} onToggle={() => setTaskDone(t.id, true)} onPress={() => openTask(t)} />
        ))
      )}

      {comingUp.length > 0 ? (
        <>
          <SectionTitle>Coming up</SectionTitle>
          {comingUp.map((t) => (
            <TaskRow key={t.id} task={t} onToggle={() => setTaskDone(t.id, true)} onPress={() => openTask(t)} />
          ))}
        </>
      ) : null}

      <SectionTitle>Next exam (Exam Timetable)</SectionTitle>
      {nextExam ? (
        <Card onPress={() => router.push({ pathname: '/exam-edit', params: { id: String(nextExam.id) } })}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 17, fontWeight: '700', color: colors.text }}>{nextExam.title}</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 4 }}>
                {nextExam.subject_name ? (
                  <>
                    <Dot color={nextExam.subject_color} size={8} />
                    <Text style={{ color: colors.sub, marginLeft: 5, marginRight: 10 }}>{nextExam.subject_name}</Text>
                  </>
                ) : null}
                <Text style={{ color: colors.sub }}>
                  {formatDate(nextExam.date)}
                  {nextExam.time ? ` at ${nextExam.time}` : ''}
                </Text>
              </View>
            </View>
            <View style={{ alignItems: 'center', backgroundColor: colors.primarySoft, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 14 }}>
              <Text style={{ fontSize: 22, fontWeight: '800', color: colors.primary }}>
                {daysBetween(today, nextExam.date)}
              </Text>
              <Text style={{ fontSize: 11, color: colors.primary, fontWeight: '700' }}>
                {daysBetween(today, nextExam.date) === 1 ? 'DAY' : 'DAYS'}
              </Text>
            </View>
          </View>
        </Card>
      ) : (
        <Card onPress={() => router.push('/exam-edit')}>
          <Text style={{ color: colors.sub }}>No exams scheduled. Tap to add one.</Text>
        </Card>
      )}

      <SectionTitle>Today's study timetable</SectionTitle>
      {classes.length === 0 ? (
        <Empty icon="school-outline" text="Nothing planned today. Build your Study Timetable in the Timetable tab." />
      ) : (
        classes.map((c) => (
          <Card key={c.id} onPress={() => router.push({ pathname: '/class-edit', params: { id: String(c.id) } })} style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{ width: 4, alignSelf: 'stretch', borderRadius: 2, backgroundColor: c.subject_color ?? colors.sub, marginRight: 12 }} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 16, fontWeight: '700', color: colors.text }}>{c.subject_name ?? (c.title || 'Study session')}</Text>
              <Text style={{ color: colors.sub, marginTop: 2 }}>
                {c.start} to {c.end}
                {c.room ? `  |  ${c.room}` : ''}
              </Text>
            </View>
          </Card>
        ))
      )}
    </Screen>
  );
}
