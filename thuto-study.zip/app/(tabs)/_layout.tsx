import React from 'react';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

const tab = (title: string, icon: IconName) => ({
  title,
  tabBarIcon: ({ color, size }: { color: string; size: number }) => <Ionicons name={icon} size={size} color={color} />,
});

export default function TabsLayout() {
  const { colors } = useTheme();
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.sub,
        tabBarStyle: { backgroundColor: colors.card, borderTopColor: colors.border },
        tabBarLabelStyle: { fontWeight: '600', fontSize: 11 },
      }}
    >
      <Tabs.Screen name="index" options={tab('Home', 'home')} />
      <Tabs.Screen name="tasks" options={tab('To Do', 'checkbox')} />
      <Tabs.Screen name="timer" options={tab('Record', 'timer')} />
      <Tabs.Screen name="planner" options={tab('Timetable', 'calendar')} />
      <Tabs.Screen name="scores" options={tab('Scores', 'trophy')} />
      <Tabs.Screen name="progress" options={tab('Progress', 'stats-chart')} />
    </Tabs>
  );
}
