import React, { useMemo, useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Subject, TestRow, addSubject, listSubjects, listTests } from '../../src/db';
import { useQuery } from '../../src/store';
import { SUBJECT_COLORS, useTheme } from '../../src/theme';
import { TourTarget } from '../../src/tour/TourTarget';
import { Bar, Button, Card, Dot, Empty, Fab, Field, Screen, SectionTitle } from '../../src/ui';
import { StatBox, TrendBadge } from '../../src/scoreUi';
import { SubjectStats, computeStats, formatPercent, summarize } from '../../src/stats';

export default function Scores() {
  const { colors } = useTheme();
  const router = useRouter();
  const subjects = useQuery<Subject[]>(listSubjects, []).data;
  const tests = useQuery<TestRow[]>(() => listTests(), []).data;
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState('');

  const rows = useMemo(
    () => subjects.map((s) => ({ subject: s, stats: computeStats(tests.filter((t) => t.subject_id === s.id)) })),
    [subjects, tests]
  );
  const tracked = rows.filter((r) => r.stats !== null);
  const overall = summarize(tracked.map((r) => r.stats as SubjectStats));

  const addNew = async () => {
    const v = name.trim();
    if (!v) return;
    if (subjects.some((s) => s.name.toLowerCase() === v.toLowerCase())) {
      Alert.alert('Already added', `${v} is already in your subjects.`);
      return;
    }
    await addSubject(v, SUBJECT_COLORS[subjects.length % SUBJECT_COLORS.length]);
    setName('');
    setAdding(false);
  };

  return (
    <Screen
      title="Test Scores"
      subtitle="Track every mark and see your progress"
      right={<Button title="Subject" icon="add" variant="soft" onPress={() => setAdding((a) => !a)} style={{ paddingVertical: 8, paddingHorizontal: 12 }} />}
      fab={<Fab onPress={() => router.push('/test-edit')} />}
    >
      {adding ? (
        <Card>
          <Field label="New subject" value={name} onChangeText={setName} placeholder="e.g. Mathematics" autoFocus onSubmitEditing={addNew} returnKeyType="done" />
          <Button title="Add subject" onPress={addNew} disabled={!name.trim()} />
        </Card>
      ) : null}

      <TourTarget id="scores-overview">
        <Card>
          <Text style={{ fontSize: 13, fontWeight: '700', color: colors.sub }}>Overall performance</Text>
          <View style={{ flexDirection: 'row', alignItems: 'baseline', marginTop: 2 }}>
            <Text style={{ fontSize: 40, fontWeight: '800', color: colors.text }}>
              {overall.tracked > 0 ? formatPercent(overall.average) : '--'}
            </Text>
            <Text style={{ color: colors.sub, marginLeft: 8 }}>average</Text>
          </View>
          <View style={{ flexDirection: 'row', marginHorizontal: -4, marginTop: 8 }}>
            <StatBox label="Subjects tracked" value={String(overall.tracked)} />
            <StatBox label="Tests completed" value={String(overall.tests)} />
          </View>
          <View style={{ flexDirection: 'row', marginHorizontal: -4 }}>
            <StatBox label="Improving" value={String(overall.improving)} tint={colors.success} />
            <StatBox label="Stable" value={String(overall.stable)} tint={colors.warning} />
            <StatBox label="Needs attention" value={String(overall.attention)} tint={colors.danger} />
          </View>
          <Text style={{ color: colors.sub, fontSize: 12, marginTop: 6 }}>
            Needs attention means a declining trend or a latest mark below 50%.
          </Text>
        </Card>
      </TourTarget>

      <SectionTitle>Subjects</SectionTitle>
      {subjects.length === 0 ? (
        <Empty icon="school-outline" text="Add a subject with the button above, then record your first test with the + button." />
      ) : (
        rows.map(({ subject, stats }) => (
          <Card
            key={subject.id}
            onPress={() => router.push({ pathname: '/subject-scores', params: { id: String(subject.id) } })}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Dot color={subject.color} size={12} />
              <Text style={{ flex: 1, marginLeft: 10, fontSize: 17, fontWeight: '700', color: colors.text }}>{subject.name}</Text>
              {stats ? (
                <Text style={{ fontSize: 24, fontWeight: '800', color: colors.text }}>{formatPercent(stats.latest)}</Text>
              ) : (
                <Text style={{ color: colors.sub }}>No tests yet</Text>
              )}
              <Ionicons name="chevron-forward" size={18} color={colors.sub} style={{ marginLeft: 6 }} />
            </View>
            {stats ? (
              <>
                <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>
                  <TrendBadge trend={stats.trend} />
                  <Text style={{ color: colors.sub, marginLeft: 10 }}>
                    Avg {formatPercent(stats.average)} | {stats.count} {stats.count === 1 ? 'test' : 'tests'}
                  </Text>
                </View>
                <View style={{ marginTop: 10 }}>
                  <Bar value={stats.latest} max={100} color={subject.color} />
                </View>
              </>
            ) : null}
          </Card>
        ))
      )}
    </Screen>
  );
}
