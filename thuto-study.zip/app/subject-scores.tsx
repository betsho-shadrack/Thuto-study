import React, { useMemo } from 'react';
import { Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Subject, TestRow, listSubjects, listTests } from '../src/db';
import { useQuery } from '../src/store';
import { useTheme } from '../src/theme';
import { ScoreChart } from '../src/charts';
import { StatBox, TrendBadge } from '../src/scoreUi';
import { Button, Card, Empty, FormScreen, SectionTitle } from '../src/ui';
import { computeStats, formatChange, formatPercent, percent, sortByDate } from '../src/stats';
import { formatDate } from '../src/dates';

const CHART_MAX = 10;

const changeColor = (n: number | null, c: { success: string; danger: string; text: string }) =>
  n === null ? c.text : Math.round(n) > 0 ? c.success : Math.round(n) < 0 ? c.danger : c.text;

export default function SubjectScores() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const subjectId = Number(id);
  const { colors } = useTheme();
  const router = useRouter();

  const subjects = useQuery<Subject[]>(listSubjects, []).data;
  const tests = useQuery<TestRow[]>(() => listTests(subjectId), [], [subjectId]).data;
  const subject = subjects.find((s) => s.id === subjectId);
  const stats = useMemo(() => computeStats(tests), [tests]);
  const sorted = useMemo(() => sortByDate(tests), [tests]);

  const shown = sorted.slice(-CHART_MAX);
  const offset = sorted.length - shown.length;
  const points = shown.map((t, i) => ({ label: `T${offset + i + 1}`, value: percent(t) }));

  const addTest = () => router.push({ pathname: '/test-edit', params: { subjectId: String(subjectId) } });

  return (
    <FormScreen>
      <Stack.Screen options={{ title: subject?.name ?? 'Subject' }} />

      {!stats ? (
        <>
          <Empty icon="document-text-outline" text={`No tests recorded for ${subject?.name ?? 'this subject'} yet.`} />
          <Button title="Add your first test" icon="add" onPress={addTest} />
        </>
      ) : (
        <>
          <Card>
            <TrendBadge trend={stats.trend} />
            <Text style={{ color: colors.text, fontSize: 16, marginTop: 10, lineHeight: 22 }}>
              {stats.sinceLast === null
                ? 'Add another test to see how you are trending.'
                : Math.round(stats.sinceLast) === 0
                ? 'Same as your previous test.'
                : `${Math.round(stats.sinceLast) > 0 ? 'Up' : 'Down'} ${Math.abs(Math.round(stats.sinceLast))}% since your previous test.`}
            </Text>
          </Card>

          <View style={{ marginHorizontal: -4 }}>
            <View style={{ flexDirection: 'row' }}>
              <StatBox label="Latest" value={formatPercent(stats.latest)} />
              <StatBox label="Average" value={formatPercent(stats.average)} />
            </View>
            <View style={{ flexDirection: 'row' }}>
              <StatBox label="Highest" value={formatPercent(stats.highest)} tint={colors.success} />
              <StatBox label="Lowest" value={formatPercent(stats.lowest)} tint={colors.danger} />
            </View>
            <View style={{ flexDirection: 'row' }}>
              <StatBox label="Tests taken" value={String(stats.count)} />
              <StatBox
                label="Since last test"
                value={stats.sinceLast === null ? '--' : formatChange(stats.sinceLast)}
                tint={changeColor(stats.sinceLast, colors)}
              />
            </View>
          </View>

          <Card style={{ marginTop: 6 }}>
            <Text style={{ fontSize: 13, fontWeight: '700', color: colors.sub }}>Overall improvement</Text>
            <Text style={{ fontSize: 30, fontWeight: '800', color: changeColor(stats.overallChange, colors), marginTop: 2 }}>
              {stats.overallChange === null ? '--' : formatChange(stats.overallChange)}
            </Text>
            <Text style={{ color: colors.sub, marginTop: 2, lineHeight: 20 }}>
              {stats.overallChange === null
                ? 'You need at least two tests to measure improvement.'
                : `From your first test (${formatPercent(stats.series[0])}) to your latest (${formatPercent(stats.latest)})${
                    stats.relativeChange !== null && Math.round(stats.relativeChange) !== 0
                      ? `, which is ${Math.abs(Math.round(stats.relativeChange))}% ${stats.relativeChange > 0 ? 'higher' : 'lower'} than where you started.`
                      : '.'
                  }`}
            </Text>
          </Card>

          <SectionTitle>Score over time</SectionTitle>
          <Card>
            <ScoreChart points={points} />
            {sorted.length > CHART_MAX ? (
              <Text style={{ color: colors.sub, fontSize: 12, marginTop: 4 }}>Showing your last {CHART_MAX} tests.</Text>
            ) : null}
          </Card>

          <SectionTitle>All tests</SectionTitle>
          {[...sorted].reverse().map((t) => (
            <Card
              key={t.id}
              onPress={() => router.push({ pathname: '/test-edit', params: { id: String(t.id) } })}
              style={{ flexDirection: 'row', alignItems: 'center' }}
            >
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 16, fontWeight: '700', color: colors.text }}>{t.name}</Text>
                <Text style={{ color: colors.sub, marginTop: 2 }}>{formatDate(t.date)}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={{ fontSize: 20, fontWeight: '800', color: colors.text }}>{formatPercent(percent(t))}</Text>
                <Text style={{ color: colors.sub, fontSize: 12 }}>
                  {t.score} / {t.max_score}
                </Text>
              </View>
            </Card>
          ))}

          <Button title="Add a test" icon="add" onPress={addTest} style={{ marginTop: 6 }} />
          <Text style={{ color: colors.sub, fontSize: 12, textAlign: 'center', marginTop: 10 }}>Tap a test to edit or delete it.</Text>
        </>
      )}
    </FormScreen>
  );
}
