import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '../src/theme';
import { Button } from '../src/ui';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

/** Final onboarding screen: finish with something useful to do, not just "Done". */
export default function Ready() {
  const { colors } = useTheme();
  const router = useRouter();

  const go = (then?: string) => {
    router.replace('/(tabs)');
    if (then) setTimeout(() => router.push(then as never), 60);
  };

  const actions: { icon: IconName; label: string; text: string; to: string }[] = [
    { icon: 'school', label: 'Add My Subjects', text: 'Choose what you are studying', to: '/settings' },
    { icon: 'calendar', label: 'Create My Study Timetable', text: 'Add your first study session', to: '/class-edit' },
    { icon: 'trophy', label: 'Add My First Test', text: 'Start tracking your marks', to: '/test-edit' },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, padding: 24, justifyContent: 'center' }}>
        <View style={{ alignItems: 'center', marginBottom: 24 }}>
          <View
            style={{
              width: 88,
              height: 88,
              borderRadius: 44,
              backgroundColor: colors.success,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="checkmark" size={52} color="#FFFFFF" />
          </View>
          <Text style={{ fontSize: 28, fontWeight: '800', color: colors.text, marginTop: 18, textAlign: 'center' }}>
            You're ready to start studying!
          </Text>
          <Text style={{ color: colors.sub, marginTop: 6, textAlign: 'center' }}>
            Pick a good first step, or head to your dashboard.
          </Text>
        </View>

        {actions.map((a) => (
          <Pressable
            key={a.label}
            accessibilityRole="button"
            onPress={() => go(a.to)}
            style={({ pressed }) => ({
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: colors.card,
              borderWidth: 1,
              borderColor: colors.border,
              borderRadius: 16,
              padding: 14,
              marginBottom: 10,
              opacity: pressed ? 0.75 : 1,
            })}
          >
            <View
              style={{
                width: 42,
                height: 42,
                borderRadius: 14,
                backgroundColor: colors.primarySoft,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Ionicons name={a.icon} size={22} color={colors.primary} />
            </View>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={{ fontWeight: '800', color: colors.text, fontSize: 16 }}>{a.label}</Text>
              <Text style={{ color: colors.sub }}>{a.text}</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.sub} />
          </Pressable>
        ))}

        <Button title="Go to Dashboard" icon="home" onPress={() => go()} style={{ marginTop: 10 }} />
      </ScrollView>
    </SafeAreaView>
  );
}
