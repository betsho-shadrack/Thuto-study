import React, { useEffect, useState } from 'react';
import { Alert } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Subject, deleteExam, getExam, listSubjects, saveExam } from '../src/db';
import { useQuery } from '../src/store';
import { Button, DatePicker, Field, FormScreen, SubjectPicker } from '../src/ui';
import { isValidTime, normalizeTime, todayISO } from '../src/dates';

export default function ExamEdit() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const editingId = id ? Number(id) : undefined;
  const router = useRouter();
  const subjects = useQuery<Subject[]>(listSubjects, []).data;

  const [title, setTitle] = useState('');
  const [subjectId, setSubjectId] = useState<number | null>(null);
  const [date, setDate] = useState<string | null>(todayISO());
  const [time, setTime] = useState('');
  const [venue, setVenue] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!editingId) return;
    getExam(editingId).then((e) => {
      if (!e) return;
      setTitle(e.title);
      setSubjectId(e.subject_id);
      setDate(e.date);
      setTime(e.time);
      setVenue(e.venue);
      setNotes(e.notes);
    });
  }, [editingId]);

  const save = async () => {
    if (!title.trim()) {
      Alert.alert('Add a title', 'For example: Mathematics Paper 1.');
      return;
    }
    if (!date) {
      Alert.alert('Pick a date', 'Choose the day of the exam.');
      return;
    }
    if (time.trim() && !isValidTime(time)) {
      Alert.alert('Check the time', 'Use 24-hour time like 08:30 or 14:00, or leave it empty.');
      return;
    }
    await saveExam({
      id: editingId,
      title,
      subject_id: subjectId,
      date,
      time: time.trim() ? normalizeTime(time) : '',
      venue,
      notes,
    });
    router.back();
  };

  const remove = () =>
    Alert.alert('Delete exam?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          if (editingId) await deleteExam(editingId);
          router.back();
        },
      },
    ]);

  return (
    <FormScreen>
      <Stack.Screen options={{ title: editingId ? 'Edit exam' : 'New exam' }} />
      <Field label="Exam" value={title} onChangeText={setTitle} placeholder="e.g. Mathematics Paper 1" autoFocus={!editingId} />
      <SubjectPicker subjects={subjects} value={subjectId} onChange={setSubjectId} />
      <DatePicker label="Date" value={date} onChange={setDate} />
      <Field label="Start time (optional)" value={time} onChangeText={setTime} placeholder="08:30" keyboardType="numbers-and-punctuation" maxLength={5} />
      <Field label="Venue (optional)" value={venue} onChangeText={setVenue} placeholder="e.g. Main hall" />
      <Field label="Notes (optional)" value={notes} onChangeText={setNotes} placeholder="Topics to revise, what to bring..." multiline style={{ minHeight: 90, textAlignVertical: 'top' }} />
      <Button title={editingId ? 'Save changes' : 'Add exam'} onPress={save} />
      {editingId ? <Button title="Delete exam" variant="danger" onPress={remove} style={{ marginTop: 12 }} /> : null}
    </FormScreen>
  );
}
