import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Subject, deleteTask, getTask, listSubjects, saveTask } from '../src/db';
import { useQuery } from '../src/store';
import { Button, DatePicker, Field, FormScreen, Label, Segmented, SubjectPicker } from '../src/ui';

export default function TaskEdit() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const editingId = id ? Number(id) : undefined;
  const router = useRouter();
  const subjects = useQuery<Subject[]>(listSubjects, []).data;

  const [title, setTitle] = useState('');
  const [subjectId, setSubjectId] = useState<number | null>(null);
  const [due, setDue] = useState<string | null>(null);
  const [priority, setPriority] = useState(1);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!editingId) return;
    getTask(editingId).then((t) => {
      if (!t) return;
      setTitle(t.title);
      setSubjectId(t.subject_id);
      setDue(t.due_date);
      setPriority(t.priority);
      setNotes(t.notes);
    });
  }, [editingId]);

  const save = async () => {
    if (!title.trim()) {
      Alert.alert('Add a title', 'Give your task a short title first.');
      return;
    }
    await saveTask({ id: editingId, title, subject_id: subjectId, due_date: due, priority, notes });
    router.back();
  };

  const remove = () =>
    Alert.alert('Delete to do?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          if (editingId) await deleteTask(editingId);
          router.back();
        },
      },
    ]);

  return (
    <FormScreen>
      <Stack.Screen options={{ title: editingId ? 'Edit to do' : 'New to do' }} />
      <Field label="Title" value={title} onChangeText={setTitle} placeholder="e.g. Finish algebra worksheet" autoFocus={!editingId} />
      <SubjectPicker subjects={subjects} value={subjectId} onChange={setSubjectId} />
      <DatePicker label="Due date" value={due} onChange={setDue} optional />
      <View style={{ marginBottom: 16 }}>
        <Label>Priority</Label>
        <Segmented
          value={priority}
          onChange={setPriority}
          options={[
            { key: 0, label: 'Low' },
            { key: 1, label: 'Medium' },
            { key: 2, label: 'High' },
          ]}
        />
      </View>
      <Field label="Notes (optional)" value={notes} onChangeText={setNotes} placeholder="Chapters, page numbers, links..." multiline style={{ minHeight: 90, textAlignVertical: 'top' }} />
      <Button title={editingId ? 'Save changes' : 'Add to do'} onPress={save} />
      {editingId ? <Button title="Delete to do" variant="danger" onPress={remove} style={{ marginTop: 12 }} /> : null}
    </FormScreen>
  );
}
