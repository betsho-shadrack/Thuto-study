import React, { useEffect, useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Subject, deleteTest, getTest, listSubjects, listTests, saveTest } from '../src/db';
import { useQuery } from '../src/store';
import { useTheme } from '../src/theme';
import { Button, Card, DatePicker, Field, FormScreen, SubjectPicker } from '../src/ui';
import { formatPercent, percent } from '../src/stats';
import { todayISO } from '../src/dates';

/** Accepts "72", "72.5" and "72,5". Returns NaN for anything else. */
const parseNumber = (s: string): number => {
  const t = s.replace(',', '.').trim();
  return t === '' ? NaN : Number(t);
};

export default function TestEdit() {
  const { id, subjectId: subjectParam } = useLocalSearchParams<{ id?: string; subjectId?: string }>();
  const editingId = id ? Number(id) : undefined;
  const router = useRouter();
  const { colors } = useTheme();
  const subjects = useQuery<Subject[]>(listSubjects, []).data;

  const [subjectId, setSubjectId] = useState<number | null>(subjectParam ? Number(subjectParam) : null);
  const [name, setName] = useState('');
  const [date, setDate] = useState<string | null>(todayISO());
  const [score, setScore] = useState('');
  const [max, setMax] = useState('100');

  useEffect(() => {
    if (!editingId) return;
    getTest(editingId).then((t) => {
      if (!t) return;
      setSubjectId(t.subject_id);
      setName(t.name);
      setDate(t.date);
      setScore(String(t.score));
      setMax(String(t.max_score));
    });
  }, [editingId]);

  const s = parseNumber(score);
  const m = parseNumber(max);
  const valid = Number.isFinite(s) && Number.isFinite(m) && m > 0 && s >= 0 && s <= m;
  const preview = valid ? formatPercent(percent({ score: s, max_score: m })) : '--';

  const save = async () => {
    if (subjectId === null) {
      Alert.alert('Choose a subject', 'Pick the subject this test belongs to.');
      return;
    }
    if (!date) {
      Alert.alert('Pick a date', 'Choose the day you wrote the test.');
      return;
    }
    if (!Number.isFinite(s) || s < 0) {
      Alert.alert('Check your score', 'Enter the mark you got, for example 72.');
      return;
    }
    if (!Number.isFinite(m) || m <= 0) {
      Alert.alert('Check the total marks', 'The total marks must be more than 0.');
      return;
    }
    if (s > m) {
      Alert.alert('Check your score', 'Your score cannot be higher than the total marks.');
      return;
    }
    const finalName = name.trim() || `Test ${(await listTests(subjectId)).length + (editingId ? 0 : 1)}`;
    await saveTest({ id: editingId, subject_id: subjectId, name: finalName, date, score: s, max_score: m });
    router.back();
  };

  const remove = () =>
    Alert.alert('Delete this test?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          if (editingId) await deleteTest(editingId);
          router.back();
        },
      },
    ]);

  return (
    <FormScreen>
      <Stack.Screen options={{ title: editingId ? 'Edit test' : 'New test' }} />

      <SubjectPicker subjects={subjects} value={subjectId} onChange={setSubjectId} allowNone={false} />
      {subjects.length === 0 ? (
        <Button title="Add subjects in Settings" variant="soft" onPress={() => router.push('/settings')} style={{ marginBottom: 16 }} />
      ) : null}

      <Field label="Test name (optional)" value={name} onChangeText={setName} placeholder="e.g. Test 1, Mid-term, Paper 2" />
      <DatePicker label="Date" value={date} onChange={setDate} />

      <View style={{ flexDirection: 'row' }}>
        <View style={{ flex: 1, marginRight: 8 }}>
          <Field label="Score" value={score} onChangeText={setScore} placeholder="72" keyboardType="decimal-pad" maxLength={7} />
        </View>
        <View style={{ flex: 1, marginLeft: 8 }}>
          <Field label="Out of (total marks)" value={max} onChangeText={setMax} placeholder="100" keyboardType="decimal-pad" maxLength={7} />
        </View>
      </View>

      <Card style={{ alignItems: 'center', marginBottom: 16 }}>
        <Text style={{ color: colors.sub, fontWeight: '700', fontSize: 13 }}>Percentage</Text>
        <Text style={{ fontSize: 36, fontWeight: '800', color: valid ? colors.primary : colors.sub }}>{preview}</Text>
      </Card>

      <Button title={editingId ? 'Save changes' : 'Save test'} onPress={save} />
      {editingId ? <Button title="Delete test" variant="danger" onPress={remove} style={{ marginTop: 12 }} /> : null}
    </FormScreen>
  );
}
