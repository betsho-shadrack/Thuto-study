import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Subject, deleteClass, getClass, listSubjects, saveClass } from '../src/db';
import { useQuery } from '../src/store';
import { Button, Chip, Field, FormScreen, Label, SubjectPicker } from '../src/ui';
import { DAYS_LONG, isValidTime, normalizeTime } from '../src/dates';

export default function ClassEdit() {
  const { id, day: dayParam } = useLocalSearchParams<{ id?: string; day?: string }>();
  const editingId = id ? Number(id) : undefined;
  const router = useRouter();
  const subjects = useQuery<Subject[]>(listSubjects, []).data;

  const [day, setDay] = useState(dayParam ? Number(dayParam) : 0);
  const [start, setStart] = useState('08:00');
  const [end, setEnd] = useState('09:00');
  const [subjectId, setSubjectId] = useState<number | null>(null);
  const [title, setTitle] = useState('');
  const [room, setRoom] = useState('');

  useEffect(() => {
    if (!editingId) return;
    getClass(editingId).then((c) => {
      if (!c) return;
      setDay(c.day);
      setStart(c.start);
      setEnd(c.end);
      setSubjectId(c.subject_id);
      setTitle(c.title);
      setRoom(c.room);
    });
  }, [editingId]);

  const save = async () => {
    if (!isValidTime(start) || !isValidTime(end)) {
      Alert.alert('Check the times', 'Use 24-hour time like 08:00 or 13:30.');
      return;
    }
    const s = normalizeTime(start);
    const e = normalizeTime(end);
    if (e <= s) {
      Alert.alert('Check the times', 'The session must end after it starts.');
      return;
    }
    if (subjectId === null && !title.trim()) {
      Alert.alert('Add a subject or title', 'Pick a subject or type a name for this study session.');
      return;
    }
    await saveClass({ id: editingId, day, start: s, end: e, subject_id: subjectId, title, room });
    router.back();
  };

  const remove = () =>
    Alert.alert('Delete study session?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          if (editingId) await deleteClass(editingId);
          router.back();
        },
      },
    ]);

  return (
    <FormScreen>
      <Stack.Screen options={{ title: editingId ? 'Edit study session' : 'New study session' }} />
      <Label>Day</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 }}>
        {DAYS_LONG.map((d, i) => (
          <Chip key={d} label={d.slice(0, 3)} selected={day === i} onPress={() => setDay(i)} />
        ))}
      </View>
      <SubjectPicker subjects={subjects} value={subjectId} onChange={setSubjectId} />
      <View style={{ flexDirection: 'row' }}>
        <View style={{ flex: 1, marginRight: 8 }}>
          <Field label="Starts" value={start} onChangeText={setStart} placeholder="08:00" keyboardType="numbers-and-punctuation" maxLength={5} />
        </View>
        <View style={{ flex: 1, marginLeft: 8 }}>
          <Field label="Ends" value={end} onChangeText={setEnd} placeholder="09:00" keyboardType="numbers-and-punctuation" maxLength={5} />
        </View>
      </View>
      <Field label="Title (optional)" value={title} onChangeText={setTitle} placeholder="e.g. Lab practical" />
      <Field label="Room (optional)" value={room} onChangeText={setRoom} placeholder="e.g. Block B, Room 4" />
      <Button title={editingId ? 'Save changes' : 'Add study session'} onPress={save} />
      {editingId ? <Button title="Delete study session" variant="danger" onPress={remove} style={{ marginTop: 12 }} /> : null}
    </FormScreen>
  );
}
