import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Redirect } from 'expo-router';
import { getSetting } from '../src/db';
import { useTheme } from '../src/theme';

/**
 * First-launch check. Onboarding is shown only when no onboarding state has been saved
 * ('completed' or 'skipped'). People who installed an earlier version already finished
 * the old setup (`onboarded`), so they go straight to the app and can replay the tour
 * from Settings.
 */
export default function Index() {
  const { colors } = useTheme();
  const [target, setTarget] = useState<'/onboarding' | '/(tabs)' | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const state = await getSetting('onboarding_state');
        const legacy = await getSetting('onboarded');
        setTarget(state || legacy === '1' ? '/(tabs)' : '/onboarding');
      } catch {
        setTarget('/onboarding');
      }
    })();
  }, []);

  if (target) return <Redirect href={target} />;
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}>
      <ActivityIndicator color={colors.primary} size="large" />
    </View>
  );
}
